# Sistema de Registro e Comprovação de Atendimentos — Instituto Semear

Projeto Integrador 2026/2 — Equipe A — Engenharia de Software, UniEVANGÉLICA, Campus Ceres.

Componente em **linha de comando**, em **Python**, com **banco relacional local (SQLite)** na 3FN.
Não há interface web nem gráfica (escopo do Bloco 2). **Todos os dados são sintéticos** (RNF-03).

## Como rodar

Precisa só do Python 3.10 ou mais novo. O `matplotlib` é opcional (serve apenas para o gráfico).

```bash
python main.py preparar        # gera a base sintética, cria o banco e faz a carga inicial
python main.py                 # abre o menu (códigos de teste: C01, E01, A01, S01)
python main.py resumo 2026 3   # resumo do 3º trimestre de 2026
python main.py consultas       # as 10 consultas gerenciais
python -m unittest -v          # 25 testes, incluindo as 8 linhas da tabela de decisão
python medir_desempenho.py     # estudo quantitativo (gera resultados/)
```

Códigos de profissional de teste: `C01` coordenação, `E01`–`E06` educadores, `A01` auxiliar administrativo, `S01` assistente social.

## Estrutura

| Arquivo | O que é | Disciplina |
|---|---|---|
| `sql/schema.sql` | Modelo físico na 3FN: 9 tabelas, chaves, CHECK e gatilhos das regras | M109 |
| `sql/consultas.sql` | As 10 consultas gerenciais (RF-08) | M109 |
| `semear/estruturas.py` | Pilha, fila de prioridade (heap), índice hash, busca linear | M108 |
| `semear/servicos.py` | Uma função por requisito funcional | M108 / M107 |
| `semear/carga.py` | Carga inicial dos registros antigos com relatório de rejeições | M109 |
| `semear/banco.py` | Conexão e criação do banco | M109 |
| `main.py` | Menu em linha de comando | M108 |
| `gerar_dados.py` | Base bruta sintética com os defeitos do dossiê (EV-04 a EV-06) | M110 |
| `medir_desempenho.py` | 30 execuções por medida, média, desvio, maior valor e gráfico | M110 |
| `tests/test_regras.py` | Testes das regras e dos requisitos | M107 / M108 |

## Rastreabilidade: requisito → código

| Requisito | Onde está | Teste |
|---|---|---|
| RF-01 Registrar frequência | `servicos.lancar_frequencia` | `TabelaDecisaoLancamento` (R1–R8) |
| RF-02 Desfazer | `servicos.desfazer` + `estruturas.Pilha` | `test_RF02_desfazer` |
| RF-03 Fila por prioridade | `servicos.chamar_proximo` + `estruturas.FilaPrioridade` | `test_RF03_RN08_fila_por_prioridade` |
| RF-04 Busca por código | `servicos.buscar_por_codigo` + `estruturas.IndiceCodigo` | `test_RF04_RF05_buscas` |
| RF-05 Busca por nome | `servicos.buscar_por_nome` + `estruturas.busca_por_nome` | `test_RF04_RF05_buscas` |
| RF-07 Referência inexistente | `servicos.lancar_frequencia`, chaves estrangeiras | `test_RF07_referencias_inexistentes` |
| RF-08 Consultas gerenciais | `sql/consultas.sql` | `python main.py consultas` |
| RF-09 Resumo trimestral | `servicos.resumo_trimestral` | `test_RF09_resumo_confere_com_contagem_manual` |
| RF-10 Auditoria | `servicos.auditoria` | `test_RF10_auditoria_mostra_quem_lancou_e_quem_corrigiu` |
| RF-11 Histórico | `servicos.historico` | `test_RF11_historico_em_ordem_decrescente` |
| RF-12 Carga inicial | `carga.carregar` | `test_RF12_RNF01_carga_sem_perda` |
| RF-13 Cadastrar participante | `servicos.cadastrar_participante` | `test_RF13_RN11_consentimento_de_crianca` |
| RF-14 Oficina e encontros | `servicos.cadastrar_oficina`, `programar_encontro` | `base_minima` nos testes |
| RF-15 Inscrição | `servicos.inscrever` | `test_RF15_RN09_vagas_e_lista_de_espera` |
| RF-16 Correção | `servicos.corrigir` | `test_RF16_correcao_guarda_anterior` |
| RN-01 Conversão das marcas | `carga.EQUIVALENCIA` (proposta — QA-06) | `test_RN01_conversao_das_marcas` |
| RN-02 Registro único | `UNIQUE (id_inscricao, id_edicao)` | R1, R2 |
| RN-03 Só inscrito ativo | gatilhos `rn03_*` | R5–R8 |
| RN-04 Três condições | `CHECK (condicao IN ('P','F','FJ'))` | R4 |
| RN-05 / RN-06 Contagem | `servicos.resumo_trimestral`, Q1 e Q2 | `test_RF09_...` |
| RN-07 Prazo de envio | `servicos.decimo_dia_util` | `test_RN07_decimo_dia_util` |
| RN-08 Prioridade legal | `estruturas.FilaPrioridade` | `test_fila_prioridade_estavel` |
| RN-09 Vagas | gatilhos `rn09_*` | `test_RF15_RN09_...` |
| RN-10 Código único | chaves primárias | `test_RF13_...` |
| RN-11 Consentimento | gatilhos `rn11_*` | `test_RF13_RN11_...` |
| RNF-01 Carga sem perda | `carga.Relatorio.fechado` | `test_RF12_RNF01_carga_sem_perda` |
| RNF-02 / RNF-04 Desempenho | `medir_desempenho.py` | `resultados/resumo.txt` |
| RNF-05 3FN | `sql/schema.sql` | — |
| RNF-06 Auditoria | gatilho `rnf06_correcao_auditada` | `test_RNF06_...` |

## Por que cada estrutura de dados (M108)

| Estrutura | Requisito | Motivo | Custo |
|---|---|---|---|
| Pilha | RF-02 | desfazer sempre o **último** lançamento | O(1) |
| Heap binário (fila de prioridade) | RF-03 | chamar sempre quem tem **maior prioridade**, e dentro dela o que chegou primeiro | O(log n) |
| Tabela hash (`dict`) | RF-04 | achar **um código exato** sem percorrer a base | O(1) em média |
| Varredura linear | RF-05 | **parte do nome** obriga a olhar todos os nomes | O(n) |

## Resultado do estudo quantitativo (M110)

Veja `resultados/resumo.txt` e `resultados/grafico_buscas.png`. Na última execução, com 10 mil participantes,
a busca por código levou cerca de 0,0006 ms, a busca por nome cerca de 13 ms e o histórico, com 50 mil registros,
cerca de 0,02 ms. Todas ficaram dentro dos limites do RNF-02 e do RNF-04. Os números variam um pouco de máquina para máquina.

## Pendências que afetam o código

- **QA-06** — a tabela de equivalência das marcas antigas (`carga.EQUIVALENCIA`) é uma proposta da equipe.
- **QA-07** — participante não inscrito que comparece: hoje o lançamento é recusado.
- **QA-01** — falta justificada aparece em coluna separada e não soma aos atendimentos.
- **RF-08** — conferir as 10 consultas de `sql/consultas.sql` com a lista oficial de perguntas do projeto.
- A carga foi escrita para a base sintética deste repositório. Para a base do dossiê, ajuste os nomes das colunas em `semear/carga.py`.
