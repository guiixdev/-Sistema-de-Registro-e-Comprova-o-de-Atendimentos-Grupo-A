"""Conexão com o banco SQLite local e criação do esquema (M109)."""
import sqlite3
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
SCHEMA = RAIZ / "sql" / "schema.sql"
BANCO_PADRAO = RAIZ / "semear.db"


class ErroRegra(Exception):
    """Recusa de uma operação por regra de negócio ou referência inexistente.

    A mensagem é sempre em português e indica o motivo (RNF-08 do Ciclo 1 / usabilidade).
    """


def conectar(caminho=BANCO_PADRAO):
    con = sqlite3.connect(str(caminho))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    return con


def criar_banco(caminho=BANCO_PADRAO, apagar=False):
    """Cria o arquivo do banco com todas as tabelas, regras e índices."""
    caminho = Path(caminho)
    if apagar and caminho.exists():
        caminho.unlink()
    con = conectar(caminho)
    con.executescript(SCHEMA.read_text(encoding="utf-8"))
    con.commit()
    return con


def traduzir_erro(exc):
    """Converte erro do SQLite em mensagem legível para o operador."""
    msg = str(exc)
    if "RN-" in msg or "RNF-" in msg or "RF-" in msg:
        return msg
    if "UNIQUE constraint failed: registro_frequencia" in msg:
        return "RN-02: o participante já tem registro neste encontro"
    if "UNIQUE constraint failed: inscricao" in msg:
        return "O participante já está inscrito nesta oficina"
    if "CHECK constraint failed" in msg and "condicao" in msg:
        return "RN-04: condição inválida — use P (presente), F (falta) ou FJ (falta justificada)"
    if "FOREIGN KEY constraint failed" in msg:
        return "RF-07: referência inexistente (participante, oficina, encontro ou profissional)"
    if "UNIQUE constraint failed" in msg:
        return "Registro duplicado: " + msg.split(":", 1)[-1].strip()
    return msg
