"""Estruturas de dados do componente (M108).

Cada estrutura foi escolhida pela operação que o requisito exige:

| Estrutura        | Requisito | Operação crítica          | Custo                     |
|------------------|-----------|---------------------------|---------------------------|
| Pilha            | RF-02     | desfazer o ÚLTIMO         | empilhar/desempilhar O(1) |
| FilaPrioridade   | RF-03     | chamar o de MAIOR priorid.| inserir/remover O(log n)  |
| IndiceCodigo     | RF-04     | achar UM código exato     | busca média O(1) (hash)   |
| busca_por_nome   | RF-05     | achar PARTE do nome       | varredura O(n)            |

A comparação entre IndiceCodigo (O(1)) e busca_por_nome (O(n)) é a que o
estudo quantitativo de M110 mede (RNF-02).
"""
import time
import unicodedata


# ---------------------------------------------------------------- Pilha (RF-02)
class Pilha:
    """Pilha (LIFO) sobre lista do Python: o topo é o fim da lista."""

    def __init__(self):
        self._itens = []

    def empilhar(self, item):
        self._itens.append(item)

    def desempilhar(self):
        if not self._itens:
            return None
        return self._itens.pop()

    def topo(self):
        return self._itens[-1] if self._itens else None

    def vazia(self):
        return not self._itens

    def __len__(self):
        return len(self._itens)


# ---------------------------------------------------------------- Fila de prioridade (RF-03, RN-08)
class FilaPrioridade:
    """Heap binário mínimo, implementado à mão.

    Cada elemento é guardado com a chave (grupo, ordem_de_chegada):
      grupo 0 = tem prioridade legal; grupo 1 = sem prioridade.
    A menor chave sai primeiro, então prioritários saem antes e, dentro do
    mesmo grupo, vale a ordem de chegada (RN-08).
    """

    def __init__(self):
        self._heap = []      # lista de (chave, item)
        self._chegada = 0    # contador para desempate estável

    def inserir(self, item, prioritario, ordem=None):
        if ordem is None:
            self._chegada += 1
            ordem = self._chegada
        else:
            self._chegada = max(self._chegada, ordem)
        chave = (0 if prioritario else 1, ordem)
        self._heap.append((chave, item))
        self._subir(len(self._heap) - 1)

    def remover(self):
        """Retira e devolve o próximo a ser chamado (ou None se vazia)."""
        if not self._heap:
            return None
        topo = self._heap[0][1]
        ultimo = self._heap.pop()
        if self._heap:
            self._heap[0] = ultimo
            self._descer(0)
        return topo

    def espiar(self):
        return self._heap[0][1] if self._heap else None

    def vazia(self):
        return not self._heap

    def __len__(self):
        return len(self._heap)

    # -- manutenção do heap
    def _subir(self, i):
        while i > 0:
            pai = (i - 1) // 2
            if self._heap[i][0] < self._heap[pai][0]:
                self._heap[i], self._heap[pai] = self._heap[pai], self._heap[i]
                i = pai
            else:
                break

    def _descer(self, i):
        n = len(self._heap)
        while True:
            esq, dir_, menor = 2 * i + 1, 2 * i + 2, i
            if esq < n and self._heap[esq][0] < self._heap[menor][0]:
                menor = esq
            if dir_ < n and self._heap[dir_][0] < self._heap[menor][0]:
                menor = dir_
            if menor == i:
                break
            self._heap[i], self._heap[menor] = self._heap[menor], self._heap[i]
            i = menor


# ---------------------------------------------------------------- Índice por código (RF-04)
class IndiceCodigo:
    """Tabela hash (dict do Python) código → dados do participante.

    Busca média O(1): o tempo não cresce com o número de participantes.
    """

    def __init__(self, registros=()):
        self._tabela = {}
        for r in registros:
            self.adicionar(r)

    def adicionar(self, registro):
        self._tabela[registro["cod_participante"].upper()] = registro

    def buscar(self, codigo):
        return self._tabela.get(str(codigo).strip().upper())

    def __len__(self):
        return len(self._tabela)


# ---------------------------------------------------------------- Busca por nome (RF-05)
def normalizar(texto):
    """Minúsculas e sem acento: "José" e "jose" ficam iguais."""
    sem_acento = unicodedata.normalize("NFKD", texto)
    sem_acento = "".join(c for c in sem_acento if not unicodedata.combining(c))
    return " ".join(sem_acento.lower().split())


def busca_por_nome(participantes, termo):
    """Varredura linear O(n) comparando o termo com cada nome normalizado.

    Devolve a lista em ordem alfabética. Parte do nome exige olhar todos os
    registros, por isso não há atalho como no índice por código.
    """
    alvo = normalizar(termo)
    if not alvo:
        return []
    achados = [p for p in participantes if alvo in normalizar(p["nome"])]
    achados.sort(key=lambda p: (normalizar(p["nome"]), p["cod_participante"]))
    return achados


def cronometrar(funcao, *args):
    """Executa a função e devolve (resultado, tempo em milissegundos)."""
    inicio = time.perf_counter()
    resultado = funcao(*args)
    return resultado, (time.perf_counter() - inicio) * 1000
