"""RF-12 — Carga inicial dos registros antigos (base bruta) para o banco.

Garante RNF-01: todo registro lido termina CARREGADO ou REJEITADO com motivo
(lidos = carregados + rejeitados). Os rejeitados vão para dados/rejeicoes.csv.

A conversão das marcas de presença segue a RN-01. A tabela EQUIVALENCIA abaixo
é a PROPOSTA da equipe e precisa ser aprovada pela coordenação (QA-06).
"""
import csv
import datetime as dt
import sqlite3
from collections import Counter
from pathlib import Path

from .banco import traduzir_erro, RAIZ

PASTA_BRUTA = RAIZ / "dados" / "bruto"
ARQ_REJEICOES = RAIZ / "dados" / "rejeicoes.csv"

# RN-01 — marca encontrada (minúscula, sem espaços) → condição válida (RN-04)
EQUIVALENCIA = {
    "p": "P", "presente": "P", "x": "P", "ok": "P",
    "f": "F", "falta": "F", "faltou": "F",
    "fj": "FJ", "justificada": "FJ", "atestado": "FJ",
}


def converter_marca(marca):
    """RN-01: devolve P, F ou FJ; ou None quando a marca não tem equivalência."""
    return EQUIVALENCIA.get(str(marca).strip().lower())


def converter_data(texto):
    """Aceita AAAA-MM-DD e DD/MM/AAAA; devolve ISO ou None (ex.: '########')."""
    t = str(texto).strip()
    for formato in ("%Y-%m-%d", "%d/%m/%Y"):
        try:
            return dt.datetime.strptime(t, formato).date().isoformat()
        except ValueError:
            pass
    return None


def corrigir_texto(texto):
    """Desfaz erro de codificação ('JoÃ£o' → 'João') e espaços sobrando."""
    t = " ".join(str(texto).split())
    if "Ã" in t or "Â" in t:
        try:
            t = t.encode("latin-1").decode("utf-8")
        except (UnicodeEncodeError, UnicodeDecodeError):
            pass
    return t


def _ler(pasta, nome):
    with open(Path(pasta) / nome, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f, delimiter=";"))


class Relatorio:
    def __init__(self):
        self.lidos = Counter()
        self.carregados = Counter()
        self.rejeitados = []          # (arquivo, linha, motivo, conteúdo original)

    def ok(self, arquivo):
        self.lidos[arquivo] += 1
        self.carregados[arquivo] += 1

    def rejeitar(self, arquivo, linha, motivo, original):
        self.lidos[arquivo] += 1
        self.rejeitados.append((arquivo, linha, motivo, ";".join(original.values())))

    def fechado(self):
        """RNF-01: confere lidos = carregados + rejeitados em cada arquivo."""
        rej = Counter(r[0] for r in self.rejeitados)
        return all(self.lidos[a] == self.carregados[a] + rej[a] for a in self.lidos)

    def resumo(self):
        rej = Counter(r[0] for r in self.rejeitados)
        linhas = [f"{'arquivo':<20}{'lidos':>8}{'carregados':>12}{'rejeitados':>12}"]
        for a in self.lidos:
            linhas.append(f"{a:<20}{self.lidos[a]:>8}{self.carregados[a]:>12}{rej[a]:>12}")
        motivos = Counter(r[2] for r in self.rejeitados)
        linhas.append("")
        linhas.append("Motivos de rejeição:")
        for m, n in motivos.most_common():
            linhas.append(f"  {n:>5}  {m}")
        linhas.append("")
        linhas.append("RNF-01 (lidos = carregados + rejeitados): " + ("ATENDE" if self.fechado() else "NÃO ATENDE"))
        return "\n".join(linhas)

    def salvar(self, caminho=ARQ_REJEICOES):
        Path(caminho).parent.mkdir(parents=True, exist_ok=True)
        with open(caminho, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow(["arquivo", "linha", "motivo", "conteudo_original"])
            w.writerows(self.rejeitados)


def carregar(con, cod_responsavel="A01", pasta=None, arquivo_rejeicoes=ARQ_REJEICOES):
    """Executa a carga completa. Devolve o Relatorio."""
    pasta = Path(pasta) if pasta is not None else PASTA_BRUTA
    rel = Relatorio()

    def inserir(arquivo, n, original, sql, params):
        try:
            con.execute(sql, params)
            rel.ok(arquivo)
            return True
        except sqlite3.IntegrityError as e:
            rel.rejeitar(arquivo, n, traduzir_erro(e), original)
            return False

    with con:
        # profissionais ---------------------------------------------------
        for n, r in enumerate(_ler(pasta, "profissionais.csv"), start=2):
            inserir("profissionais.csv", n, r, "INSERT INTO profissional VALUES (?, ?, ?)",
                    (r["codigo"].strip().upper(), corrigir_texto(r["nome"]), r["funcao"].strip()))

        # oficinas --------------------------------------------------------
        for n, r in enumerate(_ler(pasta, "oficinas.csv"), start=2):
            try:
                vagas = int(r["vagas"])
            except ValueError:
                rel.rejeitar("oficinas.csv", n, "RF-14: número de vagas inválido", r)
                continue
            inserir("oficinas.csv", n, r, "INSERT INTO oficina VALUES (?, ?, ?, ?, ?, ?)",
                    (r["codigo"].strip().upper(), corrigir_texto(r["tema"]), r["educador"].strip().upper(),
                     r["dia"].strip(), r["horario"].strip(), vagas))

        # famílias --------------------------------------------------------
        for n, r in enumerate(_ler(pasta, "familias.csv"), start=2):
            data = converter_data(r["data_referenciamento"])
            if data is None:
                rel.rejeitar("familias.csv", n, "data inválida", r)
                continue
            inserir("familias.csv", n, r, "INSERT INTO familia (cod_familia, data_referenciamento) VALUES (?, ?)",
                    (r["codigo"].strip().upper(), data))

        # participantes ---------------------------------------------------
        for n, r in enumerate(_ler(pasta, "participantes.csv"), start=2):
            data = converter_data(r["nascimento"])
            if data is None:
                rel.rejeitar("participantes.csv", n, "data inválida", r)
                continue
            prioridade = r["prioridade"].strip().lower() or "nenhuma"
            consentimento = 1 if r["consentimento"].strip().lower() in ("sim", "s", "1") else 0
            inserir("participantes.csv", n, r,
                    "INSERT INTO participante VALUES (?, ?, ?, ?, ?, ?)",
                    (r["codigo"].strip().upper(), r["familia"].strip().upper(), corrigir_texto(r["nome"]),
                     data, prioridade, consentimento))

        # frequência ------------------------------------------------------
        oficinas = {r["cod_oficina"]: dict(r) for r in con.execute("SELECT * FROM oficina")}
        participantes = {r[0] for r in con.execute("SELECT cod_participante FROM participante")}
        edicoes, inscricoes = {}, {}
        for n, r in enumerate(_ler(pasta, "frequencia.csv"), start=2):
            cod_p, cod_o = r["participante"].strip().upper(), r["oficina"].strip().upper()
            data = converter_data(r["data"])
            cond = converter_marca(r["marca"])
            if data is None:
                rel.rejeitar("frequencia.csv", n, "data inválida", r); continue
            if cond is None:
                rel.rejeitar("frequencia.csv", n, "RN-01: marca sem equivalência (conferir com a coordenação)", r); continue
            if cod_p not in participantes:
                rel.rejeitar("frequencia.csv", n, "RF-07: participante inexistente ou rejeitado no cadastro", r); continue
            if cod_o not in oficinas:
                rel.rejeitar("frequencia.csv", n, "RF-07: oficina inexistente", r); continue

            # inscrição derivada do registro antigo; sem vaga → lista de espera e o registro é recusado (RN-03/RN-09)
            chave = (cod_p, cod_o)
            if chave not in inscricoes:
                ativas = sum(1 for (p, o), (_, s) in inscricoes.items() if o == cod_o and s == "ativa")
                situacao = "ativa" if ativas < oficinas[cod_o]["vagas"] else "espera"
                pos = None if situacao == "ativa" else sum(
                    1 for (p, o), (_, s) in inscricoes.items() if o == cod_o and s == "espera") + 1
                cur = con.execute("INSERT INTO inscricao (cod_participante, cod_oficina, data_inscricao, situacao, "
                                  "posicao_espera) VALUES (?, ?, ?, ?, ?)", (cod_p, cod_o, data, situacao, pos))
                inscricoes[chave] = (cur.lastrowid, situacao)
            id_insc, situacao = inscricoes[chave]
            if situacao != "ativa":
                rel.rejeitar("frequencia.csv", n, "RN-03: inscrição não ativa (oficina sem vaga)", r); continue

            if (cod_o, data) not in edicoes:
                cur = con.execute("INSERT INTO edicao_oficina (cod_oficina, data, horario, situacao) "
                                  "VALUES (?, ?, ?, 'realizada')", (cod_o, data, oficinas[cod_o]["horario"]))
                edicoes[(cod_o, data)] = cur.lastrowid
            inserir("frequencia.csv", n, r,
                    "INSERT INTO registro_frequencia (id_inscricao, id_edicao, condicao, cod_profissional) "
                    "VALUES (?, ?, ?, ?)", (id_insc, edicoes[(cod_o, data)], cond, cod_responsavel))

        # data de inscrição = primeiro encontro com registro
        con.execute("""UPDATE inscricao SET data_inscricao = COALESCE((
                           SELECT MIN(e.data) FROM registro_frequencia r JOIN edicao_oficina e USING (id_edicao)
                            WHERE r.id_inscricao = inscricao.id_inscricao), data_inscricao)""")
    rel.salvar(arquivo_rejeicoes)
    return rel
