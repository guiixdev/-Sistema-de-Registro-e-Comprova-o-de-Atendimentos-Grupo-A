"""Operações do componente, uma por requisito funcional da Especificação v2.0.

Todas as recusas levantam ErroRegra com mensagem em português que cita a
regra (RN) ou o requisito (RF) que motivou a recusa.
"""
import calendar
import datetime as dt
import sqlite3
from pathlib import Path

from .banco import ErroRegra, traduzir_erro, RAIZ
from .estruturas import Pilha, FilaPrioridade, IndiceCodigo, busca_por_nome, cronometrar, normalizar

CONDICOES = {"P": "presente", "F": "falta", "FJ": "falta justificada"}       # RN-04
TEXTO_RN05 = ("Regra de contagem (RN-05): atendimento = registro 'presente' em encontro realizado "
              "no trimestre; falta não conta; falta justificada aparece em coluna separada até a "
              "decisão da coordenação (QA-01).")


def _data_iso(texto, campo="data"):
    try:
        return dt.date.fromisoformat(str(texto).strip()).isoformat()
    except ValueError:
        raise ErroRegra(f"{campo} inválida: use o formato AAAA-MM-DD (ex.: 2026-10-25)") from None


# feriados nacionais de data fixa (feriados móveis e municipais não estão incluídos)
FERIADOS_FIXOS = {(1, 1), (4, 21), (5, 1), (9, 7), (10, 12), (11, 2), (11, 15), (11, 20), (12, 25)}


def decimo_dia_util(ano, mes):
    """RN-07: 10º dia útil do mês (segunda a sexta, fora os feriados nacionais fixos)."""
    uteis = 0
    for dia in range(1, calendar.monthrange(ano, mes)[1] + 1):
        d = dt.date(ano, mes, dia)
        if d.weekday() < 5 and (mes, dia) not in FERIADOS_FIXOS:
            uteis += 1
            if uteis == 10:
                return d
    raise ValueError("mês sem 10 dias úteis")


class Componente:
    """Sessão de trabalho de um profissional identificado (auditoria — RNF-06)."""

    def __init__(self, con, cod_profissional):
        self.con = con
        prof = con.execute("SELECT * FROM profissional WHERE cod_profissional = ?",
                           (cod_profissional,)).fetchone()
        if prof is None:
            raise ErroRegra(f"Profissional {cod_profissional} não cadastrado")
        self.profissional = dict(prof)
        self._desfazer = Pilha()          # RF-02: lançamentos desta sessão
        self._indice = None               # RF-04: carregado sob demanda
        self._lista_nomes = None          # RF-05
        self._fila = None                 # RF-03

    # ================================================================ utilidades
    def _executar(self, sql, params=()):
        try:
            cur = self.con.execute(sql, params)
            return cur
        except sqlite3.IntegrityError as e:
            raise ErroRegra(traduzir_erro(e)) from None

    def _invalidar_cache(self):
        self._indice = None
        self._lista_nomes = None

    # ================================================================ cadastro (RF-13, RF-14)
    def cadastrar_familia(self, data_referenciamento, cod_familia=None):
        data = _data_iso(data_referenciamento, "Data de referenciamento")
        if cod_familia is None:
            cod_familia = self._proximo_codigo("familia", "cod_familia", "F")
        with self.con:
            self._executar("INSERT INTO familia (cod_familia, data_referenciamento) VALUES (?, ?)",
                           (cod_familia, data))
        return cod_familia

    def participantes_parecidos(self, nome):
        """RF-13 crit. 3: mostrar nomes parecidos antes de gravar (usa RF-05)."""
        primeiro = normalizar(nome).split(" ")[0] if nome.strip() else ""
        return self.buscar_por_nome(primeiro)[0] if primeiro else []

    def cadastrar_participante(self, cod_familia, nome, data_nascimento, prioridade_legal="nenhuma",
                               consentimento_responsavel=False, cod_participante=None):
        """RF-13 — código único gerado pela solução (RN-10); RN-11 verificada pelo banco."""
        data = _data_iso(data_nascimento, "Data de nascimento")
        if prioridade_legal not in ("nenhuma", "idoso", "gestante", "pcd"):
            raise ErroRegra("Prioridade legal inválida: use nenhuma, idoso, gestante ou pcd")
        if cod_participante is None:
            cod_participante = self._proximo_codigo("participante", "cod_participante", "P")
        with self.con:
            self._executar(
                "INSERT INTO participante (cod_participante, cod_familia, nome, data_nascimento, "
                "prioridade_legal, consentimento_responsavel) VALUES (?, ?, ?, ?, ?, ?)",
                (cod_participante, cod_familia, nome.strip(), data, prioridade_legal,
                 1 if consentimento_responsavel else 0))
        self._invalidar_cache()
        return cod_participante

    def cadastrar_oficina(self, cod_oficina, tema, cod_educador, dia_semana, horario, vagas):
        """RF-14 — educador e número de vagas obrigatórios."""
        if not cod_educador:
            raise ErroRegra("RF-14: a oficina precisa de um educador responsável")
        try:
            vagas = int(vagas)
        except (TypeError, ValueError):
            raise ErroRegra("RF-14: número de vagas deve ser um inteiro") from None
        if vagas <= 0:
            raise ErroRegra("RF-14: número de vagas deve ser maior que zero")
        with self.con:
            self._executar("INSERT INTO oficina VALUES (?, ?, ?, ?, ?, ?)",
                           (cod_oficina, tema, cod_educador, dia_semana, horario, vagas))
        return cod_oficina

    def programar_encontro(self, cod_oficina, data, horario=None, situacao="prevista"):
        """RF-14 — não há dois encontros da mesma oficina na mesma data e horário."""
        of = self.con.execute("SELECT horario FROM oficina WHERE cod_oficina = ?", (cod_oficina,)).fetchone()
        if of is None:
            raise ErroRegra(f"RF-07: oficina {cod_oficina} não cadastrada")
        horario = horario or of["horario"]
        with self.con:
            cur = self._executar(
                "INSERT INTO edicao_oficina (cod_oficina, data, horario, situacao) VALUES (?, ?, ?, ?)",
                (cod_oficina, _data_iso(data), horario, situacao))
        return cur.lastrowid

    def marcar_encontro(self, id_edicao, situacao):
        if situacao not in ("prevista", "realizada", "cancelada"):
            raise ErroRegra("Situação do encontro inválida")
        with self.con:
            self._executar("UPDATE edicao_oficina SET situacao = ? WHERE id_edicao = ?", (situacao, id_edicao))

    def encontros(self, cod_oficina):
        return [dict(r) for r in self.con.execute(
            "SELECT * FROM edicao_oficina WHERE cod_oficina = ? ORDER BY data, horario", (cod_oficina,))]

    def _proximo_codigo(self, tabela, coluna, prefixo):
        ultimo = self.con.execute(
            f"SELECT MAX(CAST(substr({coluna}, 2) AS INTEGER)) FROM {tabela} WHERE {coluna} GLOB ?",
            (prefixo + "[0-9]*",)).fetchone()[0] or 0
        return f"{prefixo}{ultimo + 1:04d}"

    # ================================================================ inscrição (RF-15, RN-09)
    def inscrever(self, cod_participante, cod_oficina, data_inscricao=None):
        """Efetiva se houver vaga; senão, coloca no fim da lista de espera."""
        data = _data_iso(data_inscricao or dt.date.today().isoformat())
        if not self.con.execute("SELECT 1 FROM participante WHERE cod_participante = ?", (cod_participante,)).fetchone():
            raise ErroRegra(f"RF-07: participante {cod_participante} não cadastrado")
        of = self.con.execute("SELECT vagas FROM oficina WHERE cod_oficina = ?", (cod_oficina,)).fetchone()
        if of is None:
            raise ErroRegra(f"RF-07: oficina {cod_oficina} não cadastrada")
        ativas = self.con.execute("SELECT COUNT(*) FROM inscricao WHERE cod_oficina = ? AND situacao = 'ativa'",
                                  (cod_oficina,)).fetchone()[0]
        with self.con:
            if ativas < of["vagas"]:
                self._executar("INSERT INTO inscricao (cod_participante, cod_oficina, data_inscricao, situacao) "
                               "VALUES (?, ?, ?, 'ativa')", (cod_participante, cod_oficina, data))
                return "ativa", None
            pos = self.con.execute("SELECT COALESCE(MAX(posicao_espera), 0) + 1 FROM inscricao "
                                   "WHERE cod_oficina = ? AND situacao = 'espera'", (cod_oficina,)).fetchone()[0]
            self._executar("INSERT INTO inscricao (cod_participante, cod_oficina, data_inscricao, situacao, "
                           "posicao_espera) VALUES (?, ?, ?, 'espera', ?)", (cod_participante, cod_oficina, data, pos))
            return "espera", pos

    # ================================================================ frequência (RF-01, RF-07, RF-02, RF-16)
    def lancar_frequencia(self, id_edicao, cod_participante, condicao):
        """RF-01 — aplica, nesta ordem, as verificações da Figura 3 e da tabela de decisão (seção 5.3)."""
        condicao = str(condicao).strip().upper()
        ed = self.con.execute("SELECT * FROM edicao_oficina WHERE id_edicao = ?", (id_edicao,)).fetchone()
        if ed is None:
            raise ErroRegra(f"RF-07: encontro {id_edicao} não cadastrado")
        if ed["situacao"] == "cancelada":
            raise ErroRegra(f"RF-07: encontro {id_edicao} está cancelado")
        if not self.con.execute("SELECT 1 FROM participante WHERE cod_participante = ?", (cod_participante,)).fetchone():
            raise ErroRegra(f"RF-07: participante {cod_participante} não cadastrado")
        insc = self.con.execute("SELECT id_inscricao, situacao FROM inscricao WHERE cod_participante = ? "
                                "AND cod_oficina = ?", (cod_participante, ed["cod_oficina"])).fetchone()
        if insc is None or insc["situacao"] != "ativa":
            # tabela de decisão R7/R8 — tratamento definitivo depende da QA-07
            raise ErroRegra(f"RN-03: {cod_participante} não tem inscrição ativa na oficina {ed['cod_oficina']}")
        if condicao not in CONDICOES:
            raise ErroRegra("RN-04: condição inválida — use P (presente), F (falta) ou FJ (falta justificada)")
        ja = self.con.execute("SELECT id_registro FROM registro_frequencia WHERE id_inscricao = ? AND id_edicao = ?",
                              (insc["id_inscricao"], id_edicao)).fetchone()
        if ja is not None:
            raise ErroRegra("RN-02: o participante já tem registro neste encontro; peça a correção à coordenação (RF-16)")
        with self.con:
            cur = self._executar("INSERT INTO registro_frequencia (id_inscricao, id_edicao, condicao, cod_profissional) "
                                 "VALUES (?, ?, ?, ?)",
                                 (insc["id_inscricao"], id_edicao, condicao, self.profissional["cod_profissional"]))
            if ed["situacao"] == "prevista":
                self.con.execute("UPDATE edicao_oficina SET situacao = 'realizada' WHERE id_edicao = ?", (id_edicao,))
        self._desfazer.empilhar(cur.lastrowid)
        return cur.lastrowid

    def desfazer(self):
        """RF-02 — remove o último lançamento DESTA sessão (pilha)."""
        id_registro = self._desfazer.desempilhar()
        if id_registro is None:
            return None
        reg = self.con.execute("SELECT r.*, i.cod_participante FROM registro_frequencia r "
                               "JOIN inscricao i USING (id_inscricao) WHERE id_registro = ?", (id_registro,)).fetchone()
        if reg is None:
            return None
        if self.con.execute("SELECT 1 FROM alteracao_frequencia WHERE id_registro = ?", (id_registro,)).fetchone():
            raise ErroRegra("RF-02: este lançamento já foi corrigido pela coordenação e não pode ser desfeito")
        with self.con:
            self.con.execute("DELETE FROM registro_frequencia WHERE id_registro = ?", (id_registro,))
        return dict(reg)

    def corrigir(self, id_registro, nova_condicao, motivo):
        """RF-16 — guarda a condição anterior, a data e quem corrigiu (RN-02, RNF-06)."""
        if self.profissional["funcao"] != "coordenacao":
            raise ErroRegra("RF-16: só a coordenação pode corrigir registros")
        nova = str(nova_condicao).strip().upper()
        if nova not in CONDICOES:
            raise ErroRegra("RN-04: condição inválida — use P, F ou FJ")
        if not motivo or not motivo.strip():
            raise ErroRegra("RF-16: informe o motivo da correção")
        reg = self.con.execute("SELECT condicao FROM registro_frequencia WHERE id_registro = ?", (id_registro,)).fetchone()
        if reg is None:
            raise ErroRegra(f"Registro {id_registro} não encontrado")
        if reg["condicao"] == nova:
            raise ErroRegra("A condição informada é igual à atual")
        with self.con:
            self._executar("INSERT INTO alteracao_frequencia (id_registro, condicao_anterior, condicao_nova, "
                           "cod_profissional, motivo) VALUES (?, ?, ?, ?, ?)",
                           (id_registro, reg["condicao"], nova, self.profissional["cod_profissional"], motivo.strip()))
            self._executar("UPDATE registro_frequencia SET condicao = ? WHERE id_registro = ?", (nova, id_registro))

    # ================================================================ buscas (RF-04, RF-05, RF-11)
    def _carregar_participantes(self):
        linhas = [dict(r) for r in self.con.execute(
            "SELECT cod_participante, nome, cod_familia, data_nascimento, prioridade_legal FROM participante")]
        self._indice = IndiceCodigo(linhas)
        self._lista_nomes = linhas

    def buscar_por_codigo(self, codigo):
        """RF-04 — tabela hash. Devolve (participante ou None, tempo em ms)."""
        if self._indice is None:
            self._carregar_participantes()
        return cronometrar(self._indice.buscar, codigo)

    def buscar_por_nome(self, termo):
        """RF-05 — varredura linear, em ordem alfabética. Devolve (lista, tempo em ms)."""
        if self._lista_nomes is None:
            self._carregar_participantes()
        return cronometrar(busca_por_nome, self._lista_nomes, termo)

    def historico(self, cod_participante):
        """RF-11 — do mais recente para o mais antigo."""
        return [dict(r) for r in self.con.execute(
            """SELECT e.data, e.horario, o.cod_oficina, o.tema, r.condicao, r.id_registro,
                      r.cod_profissional AS lancado_por, r.data_hora_lancamento
                 FROM inscricao i
                 JOIN registro_frequencia r ON r.id_inscricao = i.id_inscricao
                 JOIN edicao_oficina e ON e.id_edicao = r.id_edicao
                 JOIN oficina o ON o.cod_oficina = e.cod_oficina
                WHERE i.cod_participante = ?
                ORDER BY e.data DESC, e.horario DESC""", (cod_participante,))]

    def auditoria(self, id_edicao=None, cod_participante=None):
        """RF-10 — quem lançou e quem corrigiu cada registro."""
        filtro, params = [], []
        if id_edicao is not None:
            filtro.append("r.id_edicao = ?"); params.append(id_edicao)
        if cod_participante is not None:
            filtro.append("i.cod_participante = ?"); params.append(cod_participante)
        where = ("WHERE " + " AND ".join(filtro)) if filtro else ""
        return [dict(r) for r in self.con.execute(
            f"""SELECT r.id_registro, i.cod_participante, e.data, e.cod_oficina, r.condicao,
                       r.cod_profissional AS lancado_por, r.data_hora_lancamento,
                       a.condicao_anterior, a.condicao_nova, a.cod_profissional AS corrigido_por,
                       a.data_hora AS data_hora_correcao, a.motivo
                  FROM registro_frequencia r
                  JOIN inscricao i ON i.id_inscricao = r.id_inscricao
                  JOIN edicao_oficina e ON e.id_edicao = r.id_edicao
             LEFT JOIN alteracao_frequencia a ON a.id_registro = r.id_registro
                  {where}
              ORDER BY e.data, r.id_registro, a.id_alteracao""", params)]

    # ================================================================ fila (RF-03, RN-08)
    def _carregar_fila(self):
        self._fila = FilaPrioridade()
        for r in self.con.execute(
                """SELECT f.id_atendimento, f.cod_participante, p.nome, p.prioridade_legal
                     FROM atendimento_fila f JOIN participante p USING (cod_participante)
                    WHERE f.situacao = 'aguardando' ORDER BY f.data_hora_chegada, f.id_atendimento"""):
            self._fila.inserir(dict(r), r["prioridade_legal"] != "nenhuma", ordem=r["id_atendimento"])

    def incluir_na_fila(self, cod_participante):
        p = self.con.execute("SELECT nome, prioridade_legal FROM participante WHERE cod_participante = ?",
                             (cod_participante,)).fetchone()
        if p is None:
            raise ErroRegra(f"{cod_participante} não cadastrado: faça o cadastro antes (RF-13)")
        if self._fila is None:
            self._carregar_fila()
        with self.con:
            cur = self._executar("INSERT INTO atendimento_fila (cod_participante) VALUES (?)", (cod_participante,))
        item = {"id_atendimento": cur.lastrowid, "cod_participante": cod_participante,
                "nome": p["nome"], "prioridade_legal": p["prioridade_legal"]}
        self._fila.inserir(item, p["prioridade_legal"] != "nenhuma", ordem=cur.lastrowid)
        return len(self._fila)

    def chamar_proximo(self):
        """RF-03 — prioridade legal primeiro; no mesmo grupo, ordem de chegada (RN-08)."""
        if self._fila is None:
            self._carregar_fila()
        item = self._fila.remover()
        if item is None:
            return None
        with self.con:
            self.con.execute("UPDATE atendimento_fila SET situacao = 'atendido', "
                             "data_hora_chamada = strftime('%Y-%m-%d %H:%M:%f','now','localtime') "
                             "WHERE id_atendimento = ?", (item["id_atendimento"],))
        return item

    # ================================================================ relatórios (RF-08, RF-09)
    def resumo_trimestral(self, ano, trimestre):
        """RF-09 — totais por oficina (RN-05), famílias atendidas (RN-06) e prazo (RN-07)."""
        if trimestre not in (1, 2, 3, 4):
            raise ErroRegra("Trimestre deve ser 1, 2, 3 ou 4")
        ini = dt.date(ano, 3 * trimestre - 2, 1)
        fim_mes = 3 * trimestre
        fim = dt.date(ano, fim_mes, calendar.monthrange(ano, fim_mes)[1])
        envio = decimo_dia_util(ano + (1 if trimestre == 4 else 0), 1 if trimestre == 4 else fim_mes + 1)
        por_oficina = [dict(r) for r in self.con.execute(
            """SELECT o.cod_oficina, o.tema,
                      COUNT(DISTINCT e.id_edicao)                                    AS encontros_realizados,
                      COALESCE(SUM(r.condicao = 'P'), 0)                             AS atendimentos,
                      COUNT(DISTINCT CASE WHEN r.condicao = 'P' THEN i.cod_participante END) AS participantes_atendidos,
                      COALESCE(SUM(r.condicao = 'FJ'), 0)                            AS faltas_justificadas,
                      COALESCE(SUM(r.condicao = 'F'), 0)                             AS faltas
                 FROM oficina o
            LEFT JOIN edicao_oficina e ON e.cod_oficina = o.cod_oficina
                                      AND e.situacao = 'realizada' AND e.data BETWEEN ? AND ?
            LEFT JOIN registro_frequencia r ON r.id_edicao = e.id_edicao
            LEFT JOIN inscricao i ON i.id_inscricao = r.id_inscricao
             GROUP BY o.cod_oficina ORDER BY o.cod_oficina""", (ini.isoformat(), fim.isoformat()))]
        familias = self.con.execute(
            """SELECT COUNT(DISTINCT p.cod_familia)
                 FROM registro_frequencia r
                 JOIN edicao_oficina e ON e.id_edicao = r.id_edicao
                 JOIN inscricao i ON i.id_inscricao = r.id_inscricao
                 JOIN participante p ON p.cod_participante = i.cod_participante
                 JOIN familia f ON f.cod_familia = p.cod_familia
                WHERE r.condicao = 'P' AND e.situacao = 'realizada' AND e.data BETWEEN ? AND ?""",
            (ini.isoformat(), fim.isoformat())).fetchone()[0]
        participantes = self.con.execute(
            """SELECT COUNT(DISTINCT i.cod_participante)
                 FROM registro_frequencia r
                 JOIN edicao_oficina e ON e.id_edicao = r.id_edicao
                 JOIN inscricao i ON i.id_inscricao = r.id_inscricao
                WHERE r.condicao = 'P' AND e.situacao = 'realizada' AND e.data BETWEEN ? AND ?""",
            (ini.isoformat(), fim.isoformat())).fetchone()[0]
        return {
            "periodo": (ini.isoformat(), fim.isoformat()),
            "regra": TEXTO_RN05,
            "data_limite_envio": envio.isoformat(),
            "por_oficina": por_oficina,
            "total_atendimentos": sum(o["atendimentos"] for o in por_oficina),
            "total_participantes": participantes,
            "familias_atendidas": familias,
        }

    def consultas_gerenciais(self):
        """RF-08 — executa as 10 consultas de sql/consultas.sql. Devolve [(título, colunas, linhas)]."""
        return executar_consultas(self.con)


def ler_consultas(caminho=RAIZ / "sql" / "consultas.sql"):
    """Divide o arquivo em blocos que começam com '-- Q<n>: título'."""
    blocos, atual = [], None
    for linha in Path(caminho).read_text(encoding="utf-8").splitlines():
        if linha.startswith("-- Q") and ":" in linha:
            atual = [linha.split(":", 1)[1].strip(), []]
            blocos.append(atual)
        elif atual is not None and not linha.startswith("--"):
            atual[1].append(linha)
    return [(t, "\n".join(sql).strip().rstrip(";")) for t, sql in blocos]


def executar_consultas(con):
    saida = []
    for titulo, sql in ler_consultas():
        cur = con.execute(sql)
        colunas = [c[0] for c in cur.description]
        saida.append((titulo, colunas, [tuple(r) for r in cur.fetchall()]))
    return saida
