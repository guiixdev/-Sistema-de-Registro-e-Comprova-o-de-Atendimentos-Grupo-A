"""Componente de Registro e Comprovação de Atendimentos — Instituto Semear.

Projeto Integrador 2026/2 — Equipe A — UniEVANGÉLICA, Campus Ceres.
Dados 100% sintéticos (RNF-03).
"""
