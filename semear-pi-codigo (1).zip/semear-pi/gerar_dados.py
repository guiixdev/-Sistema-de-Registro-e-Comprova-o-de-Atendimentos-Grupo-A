"""Gera a base bruta SINTÉTICA (RNF-03) em dados/bruto/*.csv.

Reproduz os defeitos descritos no Relatório de Campo do Ciclo 1:
  EV-04 — datas "########" e em formatos misturados; 16 marcas de presença diferentes
  EV-05 — erros de codificação ("JoÃ£o") e espaços sobrando
  EV-06 — referências órfãs (participante P999, oficina OF13) e lançamentos duplicados
Também inclui uma criança sem consentimento do responsável (RN-11).

Uso:  python gerar_dados.py            (semente fixa → sempre a mesma base)
"""
import csv
import datetime as dt
import random
from pathlib import Path

SAIDA = Path(__file__).resolve().parent / "dados" / "bruto"

NOMES = ["Ana", "Bruno", "Carla", "Daniel", "Eduarda", "Felipe", "Gabriela", "Henrique", "Isabela", "João",
         "Kátia", "Lucas", "Mariana", "Nicolas", "Otávio", "Paula", "Rafael", "Sônia", "Tiago", "Úrsula",
         "Vitória", "Wesley", "Yasmin", "José", "Márcia", "Antônio", "Luíza", "Cecília", "Joaquim", "Fátima"]
SOBRENOMES = ["Silva", "Souza", "Oliveira", "Pereira", "Costa", "Rodrigues", "Almeida", "Nascimento", "Lima",
              "Araújo", "Fernandes", "Carvalho", "Gomes", "Martins", "Rocha", "Ribeiro", "Alves", "Monteiro"]
TEMAS = ["Artesanato", "Capoeira", "Horta comunitária", "Leitura em família", "Música", "Informática básica",
         "Culinária", "Teatro", "Dança", "Esporte e cidadania", "Convivência de idosos", "Cuidado com bebês"]
DIAS = ["segunda", "terça", "quarta", "quinta", "sexta", "sábado"]

# 16 marcas distintas encontradas na base (EV-04): 13 com equivalência e 3 sem
MARCAS_P = ["P", "p", "presente", "Presente", "X", "ok"]
MARCAS_F = ["F", "f", "falta", "faltou"]
MARCAS_FJ = ["FJ", "justificada", "atestado"]
MARCAS_SEM = ["?", "Maria", ""]


def estragar_data(d, rnd):
    """Datas como aparecem nas planilhas: ISO, DD/MM/AAAA ou célula corrompida."""
    sorte = rnd.random()
    if sorte < 0.01:
        return "########"
    if sorte < 0.25:
        return d.strftime("%d/%m/%Y")
    return d.isoformat()


def mojibake(texto):
    return texto.encode("utf-8").decode("latin-1")


def escrever(nome, cabecalho, linhas):
    SAIDA.mkdir(parents=True, exist_ok=True)
    with open(SAIDA / nome, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(cabecalho)
        w.writerows(linhas)


def gerar(semente=2026):
    rnd = random.Random(semente)
    hoje = dt.date(2026, 10, 25)

    # profissionais -----------------------------------------------------
    profissionais = [("C01", "Coordenação (fictícia)", "coordenacao"),
                     ("A01", "Auxiliar administrativo (fictício)", "auxiliar"),
                     ("S01", "Assistente social (fictícia)", "assistente_social")]
    profissionais += [(f"E{i:02d}", f"Educador social {i:02d} (fictício)", "educador") for i in range(1, 7)]
    escrever("profissionais.csv", ["codigo", "nome", "funcao"], profissionais)

    # oficinas: 12, cada educador conduz duas ----------------------------
    oficinas = []
    for i, tema in enumerate(TEMAS, start=1):
        oficinas.append((f"OF{i:02d}", tema, f"E{(i - 1) % 6 + 1:02d}", DIAS[(i - 1) % 6],
                         ["08:00", "14:00"][i % 2], 25))
    escrever("oficinas.csv", ["codigo", "tema", "educador", "dia", "horario", "vagas"], oficinas)

    # famílias -----------------------------------------------------------
    familias = []
    for i in range(1, 121):
        d = dt.date(2024, 1, 1) + dt.timedelta(days=rnd.randint(0, 600))
        familias.append((f"F{i:04d}", estragar_data(d, rnd) if rnd.random() < 0.3 else d.isoformat()))
    escrever("familias.csv", ["codigo", "data_referenciamento"], familias)

    # participantes ------------------------------------------------------
    participantes, validos = [], []
    for i in range(1, 281):
        nome = f"{rnd.choice(NOMES)} {rnd.choice(SOBRENOMES)} {rnd.choice(SOBRENOMES)}"
        idade = rnd.choice([rnd.randint(6, 11), rnd.randint(12, 17), rnd.randint(18, 59), rnd.randint(60, 85)])
        nasc = hoje - dt.timedelta(days=idade * 365 + rnd.randint(0, 300))
        prioridade = "idoso" if idade >= 60 else rnd.choice(["nenhuma"] * 12 + ["gestante", "pcd"]) if idade >= 18 \
            else rnd.choice(["nenhuma"] * 20 + ["pcd"])
        consentimento = "sim" if idade < 12 else rnd.choice(["sim", "não"])
        nome_bruto = mojibake(nome) if rnd.random() < 0.05 else ("  " + nome + " " if rnd.random() < 0.05 else nome)
        participantes.append([f"P{i:04d}", nome_bruto, f"F{rnd.randint(1, 120):04d}", estragar_data(nasc, rnd),
                              prioridade, consentimento])
    participantes[17][3] = "########"                                    # data corrompida
    participantes[42][3] = (hoje - dt.timedelta(days=8 * 365)).isoformat()  # criança de 8 anos...
    participantes[42][5] = "não"                                          # ...sem consentimento (RN-11)
    for p in participantes:
        validos.append(p[0])
    escrever("participantes.csv", ["codigo", "nome", "familia", "nascimento", "prioridade", "consentimento"],
             participantes)

    # inscrições implícitas: cada oficina com 18 a 24 participantes ------
    turma = {}
    for of in oficinas:
        turma[of[0]] = rnd.sample(validos, rnd.randint(18, 24))

    # frequência: julho a setembro de 2026, 8 encontros por mês ----------
    frequencia = []
    for of in oficinas:
        datas = []
        d = dt.date(2026, 7, 1)
        while d <= dt.date(2026, 9, 30):
            if d.weekday() < 6 and len([x for x in datas if x.month == d.month]) < 8 and rnd.random() < 0.4:
                datas.append(d)
            d += dt.timedelta(days=1)
        for data in datas:
            for cod in turma[of[0]]:
                r = rnd.random()
                if r < 0.78:
                    marca = rnd.choice(MARCAS_P)
                elif r < 0.92:
                    marca = rnd.choice(MARCAS_F)
                elif r < 0.985:
                    marca = rnd.choice(MARCAS_FJ)
                else:
                    marca = rnd.choice(MARCAS_SEM)
                frequencia.append([cod, of[0], estragar_data(data, rnd), marca])
    # referências órfãs (EV-06) e duplicidades
    frequencia.append(["P999", "OF03", "2026-08-12", "P"])
    frequencia.append(["P0010", "OF13", "2026-08-14", "presente"])
    for linha in rnd.sample(frequencia, 15):
        frequencia.append(list(linha))
    rnd.shuffle(frequencia)
    escrever("frequencia.csv", ["participante", "oficina", "data", "marca"], frequencia)

    return {"profissionais": len(profissionais), "oficinas": len(oficinas), "familias": len(familias),
            "participantes": len(participantes), "frequencia": len(frequencia)}


if __name__ == "__main__":
    total = gerar()
    print("Base bruta sintética gerada em", SAIDA)
    for k, v in total.items():
        print(f"  {k:<14} {v:>6} linhas")
