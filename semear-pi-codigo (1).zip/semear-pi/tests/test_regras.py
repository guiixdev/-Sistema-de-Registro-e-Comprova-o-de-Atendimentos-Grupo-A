"""Testes das regras de negócio e dos requisitos — rodar com:  python -m unittest -v

Cada linha da tabela de decisão do Catálogo (seção 5.3) tem um teste (R1 a R8).
"""
import datetime as dt
import sqlite3
import tempfile
import unittest
from pathlib import Path

from semear.banco import ErroRegra, criar_banco
from semear.carga import carregar, converter_data, converter_marca, corrigir_texto
from semear.estruturas import FilaPrioridade, IndiceCodigo, Pilha, busca_por_nome
from semear.servicos import Componente, decimo_dia_util


def base_minima():
    """Banco temporário com 1 coordenação, 1 educador, 1 oficina de 2 vagas e 3 participantes."""
    tmp = tempfile.mkdtemp()
    con = criar_banco(Path(tmp) / "teste.db")
    con.executemany("INSERT INTO profissional VALUES (?, ?, ?)",
                    [("C01", "Coord", "coordenacao"), ("E01", "Edu", "educador"), ("A01", "Aux", "auxiliar")])
    con.commit()
    coord = Componente(con, "C01")
    coord.cadastrar_familia("2025-01-10", "F0001")
    for cod, nome in [("P0001", "José da Silva"), ("P0002", "Maria Souza"), ("P0003", "Ana Lima")]:
        coord.cadastrar_participante("F0001", nome, "1990-05-01", cod_participante=cod)
    coord.cadastrar_oficina("OF01", "Música", "E01", "segunda", "14:00", 2)
    coord.inscrever("P0001", "OF01", "2026-07-01")
    coord.inscrever("P0002", "OF01", "2026-07-01")
    ed = coord.programar_encontro("OF01", "2026-07-06")
    return con, coord, Componente(con, "E01"), ed


class TabelaDecisaoLancamento(unittest.TestCase):
    """C1 = inscrição ativa (RN-03); C2 = já existe registro (RN-02); C3 = condição válida (RN-04)."""

    def setUp(self):
        self.con, self.coord, self.edu, self.ed = base_minima()

    def test_R3_registra_quando_tudo_atende(self):            # V F V
        self.edu.lancar_frequencia(self.ed, "P0001", "p")
        cond, prof = self.con.execute("SELECT condicao, cod_profissional FROM registro_frequencia").fetchone()
        self.assertEqual((cond, prof), ("P", "E01"))

    def test_R1_recusa_duplicidade(self):                      # V V V
        self.edu.lancar_frequencia(self.ed, "P0001", "P")
        with self.assertRaisesRegex(ErroRegra, "RN-02"):
            self.edu.lancar_frequencia(self.ed, "P0001", "F")

    def test_R2_recusa_duplicidade_com_condicao_invalida(self):  # V V F
        self.edu.lancar_frequencia(self.ed, "P0001", "P")
        with self.assertRaises(ErroRegra):
            self.edu.lancar_frequencia(self.ed, "P0001", "X")
        self.assertEqual(self.con.execute("SELECT COUNT(*) FROM registro_frequencia").fetchone()[0], 1)

    def test_R4_recusa_condicao_invalida(self):                # V F F
        with self.assertRaisesRegex(ErroRegra, "RN-04"):
            self.edu.lancar_frequencia(self.ed, "P0001", "presente?")

    def test_R5_R6_banco_bloqueia_registro_sem_inscricao_ativa(self):  # F V V / F V F
        id_insc = self.con.execute("SELECT id_inscricao FROM inscricao WHERE cod_participante='P0001'").fetchone()[0]
        self.con.execute("UPDATE inscricao SET situacao='encerrada' WHERE id_inscricao=?", (id_insc,))
        with self.assertRaisesRegex(sqlite3.IntegrityError, "RN-03"):
            self.con.execute("INSERT INTO registro_frequencia (id_inscricao, id_edicao, condicao, cod_profissional) "
                             "VALUES (?, ?, 'P', 'E01')", (id_insc, self.ed))

    def test_R7_recusa_participante_nao_inscrito(self):        # F F V  (tratamento final: QA-07)
        with self.assertRaisesRegex(ErroRegra, "RN-03"):
            self.edu.lancar_frequencia(self.ed, "P0003", "P")

    def test_R8_recusa_nao_inscrito_com_condicao_invalida(self):  # F F F
        with self.assertRaises(ErroRegra):
            self.edu.lancar_frequencia(self.ed, "P0003", "Z")


class RequisitosFuncionais(unittest.TestCase):
    def setUp(self):
        self.con, self.coord, self.edu, self.ed = base_minima()

    def test_RF07_referencias_inexistentes(self):
        with self.assertRaisesRegex(ErroRegra, "RF-07"):
            self.edu.lancar_frequencia(self.ed, "P999", "P")
        with self.assertRaisesRegex(ErroRegra, "RF-07"):
            self.edu.lancar_frequencia(9999, "P0001", "P")
        with self.assertRaisesRegex(ErroRegra, "RF-07"):
            self.coord.inscrever("P0001", "OF13")

    def test_RF02_desfazer(self):
        self.assertIsNone(self.edu.desfazer())                  # nada a desfazer, sem erro
        self.edu.lancar_frequencia(self.ed, "P0001", "P")
        self.edu.lancar_frequencia(self.ed, "P0002", "F")
        self.assertEqual(self.edu.desfazer()["cod_participante"], "P0002")   # último primeiro (pilha)
        self.assertEqual(self.edu.desfazer()["cod_participante"], "P0001")
        self.assertEqual(self.con.execute("SELECT COUNT(*) FROM registro_frequencia").fetchone()[0], 0)

    def test_RF16_correcao_guarda_anterior(self):
        reg = self.edu.lancar_frequencia(self.ed, "P0001", "F")
        with self.assertRaisesRegex(ErroRegra, "motivo"):
            self.coord.corrigir(reg, "FJ", "  ")
        with self.assertRaisesRegex(ErroRegra, "coordenação"):
            self.edu.corrigir(reg, "FJ", "atestado")
        self.coord.corrigir(reg, "FJ", "Atestado médico entregue")
        a = self.con.execute("SELECT condicao_anterior, condicao_nova, cod_profissional FROM alteracao_frequencia").fetchone()
        self.assertEqual(tuple(a), ("F", "FJ", "C01"))

    def test_RF10_auditoria_mostra_quem_lancou_e_quem_corrigiu(self):
        reg = self.edu.lancar_frequencia(self.ed, "P0001", "F")
        self.coord.corrigir(reg, "P", "Chegou atrasado")
        linha = self.coord.auditoria(id_edicao=self.ed)[0]
        self.assertEqual((linha["lancado_por"], linha["condicao_anterior"], linha["corrigido_por"]), ("E01", "F", "C01"))
        self.assertEqual(self.coord.auditoria(cod_participante="P0003"), [])

    def test_RNF06_banco_bloqueia_correcao_sem_auditoria(self):
        reg = self.edu.lancar_frequencia(self.ed, "P0001", "F")
        with self.assertRaisesRegex(sqlite3.IntegrityError, "RNF-06"):
            self.con.execute("UPDATE registro_frequencia SET condicao='P' WHERE id_registro=?", (reg,))

    def test_RF15_RN09_vagas_e_lista_de_espera(self):
        self.assertEqual(self.coord.inscrever("P0003", "OF01"), ("espera", 1))   # oficina de 2 vagas já cheia
        with self.assertRaisesRegex(ErroRegra, "já está inscrito"):
            self.coord.inscrever("P0001", "OF01")
        with self.assertRaisesRegex(sqlite3.IntegrityError, "RN-09"):
            self.con.execute("UPDATE inscricao SET situacao='ativa', posicao_espera=NULL WHERE cod_participante='P0003'")

    def test_RF13_RN11_consentimento_de_crianca(self):
        crianca = (dt.date.today() - dt.timedelta(days=8 * 365)).isoformat()
        with self.assertRaisesRegex(ErroRegra, "RN-11"):
            self.coord.cadastrar_participante("F0001", "Criança Teste", crianca)
        cod = self.coord.cadastrar_participante("F0001", "Criança Teste", crianca, consentimento_responsavel=True)
        self.assertEqual(cod, "P0004")                           # código novo e sequencial (RN-10)

    def test_RF04_RF05_buscas(self):
        p, ms = self.coord.buscar_por_codigo("p0001")
        self.assertEqual(p["nome"], "José da Silva")
        self.assertIsNone(self.coord.buscar_por_codigo("P9999")[0])
        nomes, _ = self.coord.buscar_por_nome("jose")
        self.assertEqual([n["cod_participante"] for n in nomes], ["P0001"])   # sem acento e minúsculo
        self.assertEqual(self.coord.buscar_por_nome("zzz")[0], [])

    def test_RF11_historico_em_ordem_decrescente(self):
        ed2 = self.coord.programar_encontro("OF01", "2026-07-13")
        self.edu.lancar_frequencia(self.ed, "P0001", "P")
        self.edu.lancar_frequencia(ed2, "P0001", "F")
        datas = [h["data"] for h in self.coord.historico("P0001")]
        self.assertEqual(datas, ["2026-07-13", "2026-07-06"])
        self.assertEqual(self.coord.historico("P0003"), [])

    def test_RF09_resumo_confere_com_contagem_manual(self):
        ed2 = self.coord.programar_encontro("OF01", "2026-08-03")
        self.edu.lancar_frequencia(self.ed, "P0001", "P")
        self.edu.lancar_frequencia(self.ed, "P0002", "FJ")
        self.edu.lancar_frequencia(ed2, "P0001", "P")
        self.edu.lancar_frequencia(ed2, "P0002", "P")
        r = self.coord.resumo_trimestral(2026, 3)
        self.assertEqual(r["total_atendimentos"], 3)             # só "presente" conta (RN-05)
        self.assertEqual(r["por_oficina"][0]["faltas_justificadas"], 1)
        self.assertEqual(r["familias_atendidas"], 1)             # RN-06
        self.assertIn("RN-05", r["regra"])
        vazio = self.coord.resumo_trimestral(2026, 1)
        self.assertEqual(vazio["total_atendimentos"], 0)         # trimestre sem encontros: zero, sem erro

    def test_RN07_decimo_dia_util(self):
        self.assertEqual(decimo_dia_util(2026, 10), dt.date(2026, 10, 15))   # 12/10 é feriado
        self.assertEqual(decimo_dia_util(2026, 1), dt.date(2026, 1, 15))   # 01/01 é feriado

    def test_RF03_RN08_fila_por_prioridade(self):
        self.coord.cadastrar_participante("F0001", "Idoso", "1950-01-01", "idoso", cod_participante="P0010")
        self.coord.cadastrar_participante("F0001", "Gestante", "1995-01-01", "gestante", cod_participante="P0011")
        for cod in ["P0001", "P0010", "P0002", "P0011", "P0003"]:
            self.coord.incluir_na_fila(cod)
        with self.assertRaises(ErroRegra):
            self.coord.incluir_na_fila("P0001")                  # já aguardando
        chamados = [self.coord.chamar_proximo()["cod_participante"] for _ in range(5)]
        self.assertEqual(chamados, ["P0010", "P0011", "P0001", "P0002", "P0003"])
        self.assertIsNone(self.coord.chamar_proximo())           # fila vazia, sem erro


class Estruturas(unittest.TestCase):
    def test_pilha(self):
        p = Pilha()
        for x in (1, 2, 3):
            p.empilhar(x)
        self.assertEqual([p.desempilhar(), p.desempilhar(), p.desempilhar(), p.desempilhar()], [3, 2, 1, None])

    def test_fila_prioridade_estavel(self):
        f = FilaPrioridade()
        for nome, prio in [("a", False), ("b", True), ("c", False), ("d", True), ("e", False)]:
            f.inserir(nome, prio)
        self.assertEqual([f.remover() for _ in range(5)], ["b", "d", "a", "c", "e"])

    def test_indice_e_busca(self):
        dados = [{"cod_participante": "P0001", "nome": "Sônia Araújo"}, {"cod_participante": "P0002", "nome": "Ana"}]
        self.assertEqual(IndiceCodigo(dados).buscar(" p0002 ")["nome"], "Ana")
        self.assertEqual(len(busca_por_nome(dados, "SONIA")), 1)


class Carga(unittest.TestCase):
    def test_RN01_conversao_das_marcas(self):
        self.assertEqual([converter_marca(m) for m in ["X", " presente ", "faltou", "atestado", "Maria", ""]],
                         ["P", "P", "F", "FJ", None, None])

    def test_datas_e_texto(self):
        self.assertEqual(converter_data("16/07/2026"), "2026-07-16")
        self.assertIsNone(converter_data("########"))
        self.assertEqual(corrigir_texto("  JoÃ£o   Souza "), "João Souza")

    def test_RF12_RNF01_carga_sem_perda(self):
        import gerar_dados
        tmp = Path(tempfile.mkdtemp())
        gerar_dados.SAIDA = tmp / "bruto"
        gerar_dados.gerar()
        con = criar_banco(tmp / "carga.db")
        rel = carregar(con, pasta=tmp / "bruto", arquivo_rejeicoes=tmp / "rej.csv")
        self.assertTrue(rel.fechado())                            # lidos = carregados + rejeitados
        motivos = " ".join(r[2] for r in rel.rejeitados)
        for esperado in ["data inválida", "RN-01", "RN-02", "RN-11", "RF-07"]:
            self.assertIn(esperado, motivos)
        carregados = con.execute("SELECT COUNT(*) FROM registro_frequencia").fetchone()[0]
        self.assertEqual(carregados, rel.carregados["frequencia.csv"])


if __name__ == "__main__":
    unittest.main()
