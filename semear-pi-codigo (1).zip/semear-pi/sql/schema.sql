-- =====================================================================
-- Sistema de Registro e Comprovação de Atendimentos — Instituto Semear
-- Modelo físico (SQLite) na 3ª forma normal — M109
-- Tabelas = entidades da seção 7.1 e da Figura 2 da Especificação v2.0
-- As regras de negócio que o banco consegue garantir sozinho estão
-- marcadas com o identificador do Catálogo de Regras de Negócio v2.0.
-- =====================================================================
PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------
-- FAMILIA — família referenciada (RN-10: código único e permanente)
-- ---------------------------------------------------------------------
CREATE TABLE familia (
    cod_familia           TEXT PRIMARY KEY,
    data_referenciamento  TEXT NOT NULL CHECK (date(data_referenciamento) = data_referenciamento),
    situacao              TEXT NOT NULL DEFAULT 'ativa' CHECK (situacao IN ('ativa', 'inativa'))
);

-- ---------------------------------------------------------------------
-- PARTICIPANTE (RN-10, RN-11)
-- prioridade_legal: só a categoria, sem laudo (LGPD — seção 7.2)
-- ---------------------------------------------------------------------
CREATE TABLE participante (
    cod_participante           TEXT PRIMARY KEY,
    cod_familia                TEXT NOT NULL REFERENCES familia (cod_familia),
    nome                       TEXT NOT NULL CHECK (length(trim(nome)) > 0),
    data_nascimento            TEXT NOT NULL CHECK (date(data_nascimento) = data_nascimento),
    prioridade_legal           TEXT NOT NULL DEFAULT 'nenhuma'
                               CHECK (prioridade_legal IN ('nenhuma', 'idoso', 'gestante', 'pcd')),
    consentimento_responsavel  INTEGER NOT NULL DEFAULT 0 CHECK (consentimento_responsavel IN (0, 1))
);

-- RN-11: criança (menos de 12 anos) só com consentimento do responsável
CREATE TRIGGER rn11_consentimento_ins
BEFORE INSERT ON participante
WHEN NEW.consentimento_responsavel = 0
 AND date(NEW.data_nascimento, '+12 years') > date('now')
BEGIN
    SELECT RAISE(ABORT, 'RN-11: menor de 12 anos sem consentimento do responsável');
END;

CREATE TRIGGER rn11_consentimento_upd
BEFORE UPDATE OF consentimento_responsavel, data_nascimento ON participante
WHEN NEW.consentimento_responsavel = 0
 AND date(NEW.data_nascimento, '+12 years') > date('now')
BEGIN
    SELECT RAISE(ABORT, 'RN-11: menor de 12 anos sem consentimento do responsável');
END;

-- ---------------------------------------------------------------------
-- PROFISSIONAL — só código, nome e função (sem documentos pessoais)
-- ---------------------------------------------------------------------
CREATE TABLE profissional (
    cod_profissional  TEXT PRIMARY KEY,
    nome              TEXT NOT NULL,
    funcao            TEXT NOT NULL
                      CHECK (funcao IN ('coordenacao', 'educador', 'auxiliar', 'assistente_social'))
);

-- ---------------------------------------------------------------------
-- OFICINA (RF-14: educador e vagas obrigatórios)
-- ---------------------------------------------------------------------
CREATE TABLE oficina (
    cod_oficina   TEXT PRIMARY KEY,
    tema          TEXT NOT NULL,
    cod_educador  TEXT NOT NULL REFERENCES profissional (cod_profissional),
    dia_semana    TEXT NOT NULL,
    horario       TEXT NOT NULL,
    vagas         INTEGER NOT NULL CHECK (vagas > 0)
);

-- ---------------------------------------------------------------------
-- EDICAO_OFICINA — cada encontro (RF-14: sem dois encontros iguais)
-- ---------------------------------------------------------------------
CREATE TABLE edicao_oficina (
    id_edicao    INTEGER PRIMARY KEY,
    cod_oficina  TEXT NOT NULL REFERENCES oficina (cod_oficina),
    data         TEXT NOT NULL CHECK (date(data) = data),
    horario      TEXT NOT NULL,
    situacao     TEXT NOT NULL DEFAULT 'prevista'
                 CHECK (situacao IN ('prevista', 'realizada', 'cancelada')),
    UNIQUE (cod_oficina, data, horario)
);

-- ---------------------------------------------------------------------
-- INSCRICAO — classe de associação participante × oficina (RN-09)
-- ---------------------------------------------------------------------
CREATE TABLE inscricao (
    id_inscricao      INTEGER PRIMARY KEY,
    cod_participante  TEXT NOT NULL REFERENCES participante (cod_participante),
    cod_oficina       TEXT NOT NULL REFERENCES oficina (cod_oficina),
    data_inscricao    TEXT NOT NULL CHECK (date(data_inscricao) = data_inscricao),
    situacao          TEXT NOT NULL CHECK (situacao IN ('ativa', 'espera', 'encerrada')),
    posicao_espera    INTEGER CHECK (posicao_espera IS NULL OR posicao_espera > 0),
    UNIQUE (cod_participante, cod_oficina),
    CHECK ((situacao = 'espera') = (posicao_espera IS NOT NULL))
);

-- RN-09: inscrições ativas nunca acima do número de vagas
CREATE TRIGGER rn09_vagas_ins
BEFORE INSERT ON inscricao
WHEN NEW.situacao = 'ativa'
 AND (SELECT COUNT(*) FROM inscricao WHERE cod_oficina = NEW.cod_oficina AND situacao = 'ativa')
     >= (SELECT vagas FROM oficina WHERE cod_oficina = NEW.cod_oficina)
BEGIN
    SELECT RAISE(ABORT, 'RN-09: oficina sem vaga');
END;

CREATE TRIGGER rn09_vagas_upd
BEFORE UPDATE OF situacao ON inscricao
WHEN NEW.situacao = 'ativa' AND OLD.situacao <> 'ativa'
 AND (SELECT COUNT(*) FROM inscricao WHERE cod_oficina = NEW.cod_oficina AND situacao = 'ativa')
     >= (SELECT vagas FROM oficina WHERE cod_oficina = NEW.cod_oficina)
BEGIN
    SELECT RAISE(ABORT, 'RN-09: oficina sem vaga');
END;

-- ---------------------------------------------------------------------
-- REGISTRO_FREQUENCIA (RN-02, RN-03, RN-04, RF-07)
-- ---------------------------------------------------------------------
CREATE TABLE registro_frequencia (
    id_registro           INTEGER PRIMARY KEY,
    id_inscricao          INTEGER NOT NULL REFERENCES inscricao (id_inscricao),
    id_edicao             INTEGER NOT NULL REFERENCES edicao_oficina (id_edicao),
    condicao              TEXT NOT NULL CHECK (condicao IN ('P', 'F', 'FJ')),          -- RN-04
    data_hora_lancamento  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%f', 'now', 'localtime')),
    cod_profissional      TEXT NOT NULL REFERENCES profissional (cod_profissional),
    UNIQUE (id_inscricao, id_edicao)                                                    -- RN-02
);

-- RN-03: só inscrição ATIVA, e o encontro tem de ser da mesma oficina da inscrição
CREATE TRIGGER rn03_inscricao_ativa
BEFORE INSERT ON registro_frequencia
WHEN (SELECT situacao FROM inscricao WHERE id_inscricao = NEW.id_inscricao) IS NOT 'ativa'
BEGIN
    SELECT RAISE(ABORT, 'RN-03: participante sem inscrição ativa na oficina');
END;

CREATE TRIGGER rn03_mesma_oficina
BEFORE INSERT ON registro_frequencia
WHEN (SELECT cod_oficina FROM inscricao WHERE id_inscricao = NEW.id_inscricao)
     IS NOT (SELECT cod_oficina FROM edicao_oficina WHERE id_edicao = NEW.id_edicao)
BEGIN
    SELECT RAISE(ABORT, 'RN-03: o encontro não é da oficina em que o participante está inscrito');
END;

CREATE TRIGGER edicao_cancelada
BEFORE INSERT ON registro_frequencia
WHEN (SELECT situacao FROM edicao_oficina WHERE id_edicao = NEW.id_edicao) = 'cancelada'
BEGIN
    SELECT RAISE(ABORT, 'RF-07: encontro cancelado');
END;

-- ---------------------------------------------------------------------
-- ALTERACAO_FREQUENCIA — histórico das correções (RN-02, RF-10, RF-16)
-- ---------------------------------------------------------------------
CREATE TABLE alteracao_frequencia (
    id_alteracao       INTEGER PRIMARY KEY,
    id_registro        INTEGER NOT NULL REFERENCES registro_frequencia (id_registro),
    condicao_anterior  TEXT NOT NULL CHECK (condicao_anterior IN ('P', 'F', 'FJ')),
    condicao_nova      TEXT NOT NULL CHECK (condicao_nova IN ('P', 'F', 'FJ')),
    data_hora          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%f', 'now', 'localtime')),
    cod_profissional   TEXT NOT NULL REFERENCES profissional (cod_profissional),
    motivo             TEXT NOT NULL CHECK (length(trim(motivo)) > 0)
);

-- RNF-06: mudar a condição sem registrar a alteração é bloqueado
CREATE TRIGGER rnf06_correcao_auditada
BEFORE UPDATE OF condicao ON registro_frequencia
WHEN NOT EXISTS (
    SELECT 1 FROM alteracao_frequencia
     WHERE id_registro = OLD.id_registro
       AND condicao_anterior = OLD.condicao
       AND condicao_nova = NEW.condicao
       AND id_alteracao = (SELECT MAX(id_alteracao) FROM alteracao_frequencia WHERE id_registro = OLD.id_registro)
)
BEGIN
    SELECT RAISE(ABORT, 'RNF-06: correção sem registro de alteração (use a função de correção)');
END;

-- ---------------------------------------------------------------------
-- ATENDIMENTO_FILA — fila da assistente social (RN-08)
-- ---------------------------------------------------------------------
CREATE TABLE atendimento_fila (
    id_atendimento    INTEGER PRIMARY KEY,
    cod_participante  TEXT NOT NULL REFERENCES participante (cod_participante),
    data_hora_chegada TEXT NOT NULL DEFAULT (strftime('%Y-%m-%d %H:%M:%f', 'now', 'localtime')),
    data_hora_chamada TEXT,
    situacao          TEXT NOT NULL DEFAULT 'aguardando' CHECK (situacao IN ('aguardando', 'atendido'))
);

-- a mesma pessoa não aguarda duas vezes
CREATE UNIQUE INDEX ux_fila_aguardando ON atendimento_fila (cod_participante) WHERE situacao = 'aguardando';

-- ---------------------------------------------------------------------
-- Índices para as consultas mais usadas (RNF-02, RNF-04)
-- ---------------------------------------------------------------------
CREATE INDEX ix_participante_familia ON participante (cod_familia);
CREATE INDEX ix_inscricao_participante ON inscricao (cod_participante);
CREATE INDEX ix_inscricao_oficina ON inscricao (cod_oficina, situacao);
CREATE INDEX ix_registro_inscricao ON registro_frequencia (id_inscricao);
CREATE INDEX ix_registro_edicao ON registro_frequencia (id_edicao);
CREATE INDEX ix_edicao_data ON edicao_oficina (data);
CREATE INDEX ix_alteracao_registro ON alteracao_frequencia (id_registro);
