-- =====================================================================
-- RF-08 — Consultas gerenciais (SQLite)
-- Cada bloco começa com "-- Q<n>: título" (o componente lê esse formato).
-- Período de referência: o último trimestre com encontros realizados.
-- ATENÇÃO: conferir estas 10 perguntas com a lista oficial do projeto.
-- =====================================================================

-- Q1: Atendimentos (presenças) por oficina no trimestre — RN-05
WITH ref AS (
  SELECT date(MAX(data), 'start of month', '-' || ((CAST(strftime('%m', MAX(data)) AS INTEGER) - 1) % 3) || ' months') AS ini,
         date(MAX(data), 'start of month', '-' || ((CAST(strftime('%m', MAX(data)) AS INTEGER) - 1) % 3) || ' months', '+3 months', '-1 day') AS fim
    FROM edicao_oficina WHERE situacao = 'realizada')
SELECT o.cod_oficina, o.tema, COUNT(r.id_registro) AS atendimentos
  FROM oficina o
  LEFT JOIN edicao_oficina e ON e.cod_oficina = o.cod_oficina AND e.situacao = 'realizada'
                            AND e.data BETWEEN (SELECT ini FROM ref) AND (SELECT fim FROM ref)
  LEFT JOIN registro_frequencia r ON r.id_edicao = e.id_edicao AND r.condicao = 'P'
 GROUP BY o.cod_oficina
 ORDER BY atendimentos DESC;

-- Q2: Famílias atendidas e famílias referenciadas no trimestre — RN-06
WITH ref AS (
  SELECT date(MAX(data), 'start of month', '-' || ((CAST(strftime('%m', MAX(data)) AS INTEGER) - 1) % 3) || ' months') AS ini,
         date(MAX(data), 'start of month', '-' || ((CAST(strftime('%m', MAX(data)) AS INTEGER) - 1) % 3) || ' months', '+3 months', '-1 day') AS fim
    FROM edicao_oficina WHERE situacao = 'realizada')
SELECT (SELECT COUNT(*) FROM familia WHERE situacao = 'ativa') AS familias_referenciadas,
       COUNT(DISTINCT p.cod_familia) AS familias_atendidas
  FROM registro_frequencia r
  JOIN edicao_oficina e ON e.id_edicao = r.id_edicao
  JOIN inscricao i ON i.id_inscricao = r.id_inscricao
  JOIN participante p ON p.cod_participante = i.cod_participante
 WHERE r.condicao = 'P' AND e.situacao = 'realizada'
   AND e.data BETWEEN (SELECT ini FROM ref) AND (SELECT fim FROM ref);

-- Q3: Percentual de frequência de cada participante por oficina (presenças ÷ registros)
SELECT i.cod_participante, i.cod_oficina,
       SUM(r.condicao = 'P') AS presencas, COUNT(*) AS registros,
       ROUND(100.0 * SUM(r.condicao = 'P') / COUNT(*), 1) AS percentual
  FROM registro_frequencia r
  JOIN inscricao i ON i.id_inscricao = r.id_inscricao
 GROUP BY i.cod_participante, i.cod_oficina
 ORDER BY percentual ASC, i.cod_participante
 LIMIT 20;

-- Q4: Participantes inscritos sem presença nos últimos 30 dias da base (busca ativa — QA-02)
WITH ultimo AS (SELECT MAX(data) AS d FROM edicao_oficina WHERE situacao = 'realizada')
SELECT i.cod_participante, p.nome, i.cod_oficina,
       MAX(CASE WHEN r.condicao = 'P' THEN e.data END) AS ultima_presenca
  FROM inscricao i
  JOIN participante p ON p.cod_participante = i.cod_participante
  LEFT JOIN registro_frequencia r ON r.id_inscricao = i.id_inscricao
  LEFT JOIN edicao_oficina e ON e.id_edicao = r.id_edicao
 WHERE i.situacao = 'ativa'
 GROUP BY i.id_inscricao
HAVING ultima_presenca IS NULL OR ultima_presenca < date((SELECT d FROM ultimo), '-30 days')
 ORDER BY ultima_presenca;

-- Q5: Ocupação das oficinas (inscrições ativas ÷ vagas) — RN-09
SELECT o.cod_oficina, o.tema, o.vagas,
       SUM(i.situacao = 'ativa') AS inscritos,
       ROUND(100.0 * SUM(i.situacao = 'ativa') / o.vagas, 1) AS ocupacao_percentual
  FROM oficina o
  LEFT JOIN inscricao i ON i.cod_oficina = o.cod_oficina
 GROUP BY o.cod_oficina
 ORDER BY ocupacao_percentual DESC;

-- Q6: Lista de espera por oficina, em ordem — RN-09
SELECT i.cod_oficina, i.posicao_espera, i.cod_participante, p.nome, i.data_inscricao
  FROM inscricao i JOIN participante p ON p.cod_participante = i.cod_participante
 WHERE i.situacao = 'espera'
 ORDER BY i.cod_oficina, i.posicao_espera;

-- Q7: Encontros realizados por oficina e mês
SELECT cod_oficina, strftime('%Y-%m', data) AS mes, COUNT(*) AS encontros_realizados
  FROM edicao_oficina
 WHERE situacao = 'realizada'
 GROUP BY cod_oficina, mes
 ORDER BY cod_oficina, mes;

-- Q8: Faltas e faltas justificadas por oficina — base da decisão da QA-01
SELECT e.cod_oficina,
       SUM(r.condicao = 'F') AS faltas,
       SUM(r.condicao = 'FJ') AS faltas_justificadas,
       ROUND(100.0 * SUM(r.condicao IN ('F', 'FJ')) / COUNT(*), 1) AS percentual_ausencia
  FROM registro_frequencia r JOIN edicao_oficina e ON e.id_edicao = r.id_edicao
 GROUP BY e.cod_oficina
 ORDER BY percentual_ausencia DESC;

-- Q9: Lançamentos por profissional (auditoria — RF-10)
SELECT pr.cod_profissional, pr.funcao, COUNT(r.id_registro) AS lancamentos,
       MIN(r.data_hora_lancamento) AS primeiro, MAX(r.data_hora_lancamento) AS ultimo
  FROM profissional pr
  LEFT JOIN registro_frequencia r ON r.cod_profissional = pr.cod_profissional
 GROUP BY pr.cod_profissional
 ORDER BY lancamentos DESC;

-- Q10: Correções de frequência com valor anterior e motivo (RF-16, RNF-06)
SELECT a.data_hora, a.cod_profissional AS corrigido_por, i.cod_participante, e.cod_oficina, e.data,
       a.condicao_anterior, a.condicao_nova, a.motivo
  FROM alteracao_frequencia a
  JOIN registro_frequencia r ON r.id_registro = a.id_registro
  JOIN inscricao i ON i.id_inscricao = r.id_inscricao
  JOIN edicao_oficina e ON e.id_edicao = r.id_edicao
 ORDER BY a.data_hora DESC;
