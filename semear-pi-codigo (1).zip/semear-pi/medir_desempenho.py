"""Estudo quantitativo (M110) — RNF-02 e RNF-04.

Mede, em bases sintéticas de tamanhos crescentes, 30 execuções de:
  • busca por código  (tabela hash — O(1))       limite RNF-02: 50 ms com 10 mil participantes
  • busca por nome    (varredura linear — O(n))  limite RNF-02: 500 ms com 10 mil participantes
  • histórico de um participante (SQL com índice) limite RNF-04: 200 ms com 50 mil registros

Saídas em resultados/:
  medicoes.csv          todas as execuções (para refazer as contas na planilha)
  resumo.txt            média, desvio padrão, maior valor e veredito de cada RNF
  grafico_buscas.png    tempo médio × número de participantes (código vs nome)

Uso:  python medir_desempenho.py
"""
import csv
import gc
import random
import statistics
import tempfile
from pathlib import Path

from semear.banco import criar_banco
from semear.estruturas import cronometrar
from semear.servicos import Componente

SAIDA = Path(__file__).resolve().parent / "resultados"
TAMANHOS = [1000, 2500, 5000, 10000, 20000]
EXECUCOES = 30
NOMES = ["Ana", "Bruno", "Carla", "Daniel", "Eduarda", "Felipe", "Gabriela", "Henrique", "Isabela", "João",
         "Lucas", "Mariana", "Paula", "Rafael", "Sônia", "Tiago", "Vitória", "José", "Márcia", "Antônio"]
SOBRENOMES = ["Silva", "Souza", "Oliveira", "Pereira", "Costa", "Rodrigues", "Almeida", "Lima", "Araújo", "Gomes"]


def montar_base(n_participantes, registros_por_participante=0, semente=1):
    """Base sintética: n participantes; opcionalmente k registros de frequência para cada um."""
    rnd = random.Random(semente)
    con = criar_banco(Path(tempfile.mkdtemp()) / "medicao.db")
    with con:
        con.executemany("INSERT INTO profissional VALUES (?, ?, ?)",
                        [("C01", "Coord", "coordenacao"), ("E01", "Edu", "educador")])
        n_fam = n_participantes // 3 + 1
        con.executemany("INSERT INTO familia (cod_familia, data_referenciamento) VALUES (?, '2025-01-01')",
                        [(f"F{i:05d}",) for i in range(1, n_fam + 1)])
        con.executemany(
            "INSERT INTO participante VALUES (?, ?, ?, '1990-01-01', 'nenhuma', 1)",
            [(f"P{i:05d}", f"F{rnd.randint(1, n_fam):05d}",
              f"{rnd.choice(NOMES)} {rnd.choice(SOBRENOMES)} {rnd.choice(SOBRENOMES)}")
             for i in range(1, n_participantes + 1)])
        if registros_por_participante:
            n_of = n_participantes // 100
            con.executemany("INSERT INTO oficina VALUES (?, 'Oficina', 'E01', 'segunda', '14:00', 100)",
                            [(f"OF{o:03d}",) for o in range(1, n_of + 1)])
            con.executemany(
                "INSERT INTO inscricao (cod_participante, cod_oficina, data_inscricao, situacao) "
                "VALUES (?, ?, '2026-01-05', 'ativa')",
                [(f"P{i:05d}", f"OF{(i - 1) // 100 + 1:03d}") for i in range(1, n_participantes + 1)])
            datas = [f"2026-{m:02d}-{d:02d}" for m in range(1, 13) for d in (5, 19)][:registros_por_participante]
            con.executemany("INSERT INTO edicao_oficina (cod_oficina, data, horario, situacao) "
                            "VALUES (?, ?, '14:00', 'realizada')",
                            [(f"OF{o:03d}", d) for o in range(1, n_of + 1) for d in datas])
            con.execute(
                """INSERT INTO registro_frequencia (id_inscricao, id_edicao, condicao, cod_profissional)
                   SELECT i.id_inscricao, e.id_edicao,
                          CASE abs(random()) % 10 WHEN 0 THEN 'F' WHEN 1 THEN 'FJ' ELSE 'P' END, 'E01'
                     FROM inscricao i JOIN edicao_oficina e ON e.cod_oficina = i.cod_oficina""")
    return con


def estatisticas(tempos):
    return statistics.mean(tempos), statistics.stdev(tempos), max(tempos)


def medir():
    SAIDA.mkdir(exist_ok=True)
    rnd = random.Random(42)
    linhas, medias = [], {"codigo": [], "nome": []}
    resultados = {}

    for n in TAMANHOS:
        c = Componente(montar_base(n), "C01")
        for _ in range(5):                               # aquecimento: carrega o índice (fora da medição)
            c.buscar_por_codigo("P00001"); c.buscar_por_nome("Ana")
        gc.disable()                                     # como o timeit: sem pausas do coletor de lixo
        tempos_cod = [c.buscar_por_codigo(f"P{rnd.randint(1, n):05d}")[1] for _ in range(EXECUCOES)]
        tempos_nome = [c.buscar_por_nome(rnd.choice(NOMES)[:4])[1] for _ in range(EXECUCOES)]
        gc.enable()
        for op, ts in (("busca por código", tempos_cod), ("busca por nome", tempos_nome)):
            linhas += [(op, n, i + 1, f"{t:.6f}") for i, t in enumerate(ts)]
        medias["codigo"].append(statistics.mean(tempos_cod))
        medias["nome"].append(statistics.mean(tempos_nome))
        resultados[n] = (estatisticas(tempos_cod), estatisticas(tempos_nome))
        print(f"  {n:>6} participantes  código {medias['codigo'][-1]:.4f} ms   nome {medias['nome'][-1]:.2f} ms")

    # RNF-04: 10 mil participantes × 5 registros = 50 mil registros de frequência
    c = Componente(montar_base(10000, registros_por_participante=5), "C01")
    total_reg = c.con.execute("SELECT COUNT(*) FROM registro_frequencia").fetchone()[0]
    c.historico("P00001")
    gc.disable()
    tempos_hist = [cronometrar(c.historico, f"P{rnd.randint(1, 10000):05d}")[1] for _ in range(EXECUCOES)]
    gc.enable()
    linhas += [("histórico", total_reg, i + 1, f"{t:.6f}") for i, t in enumerate(tempos_hist)]

    with open(SAIDA / "medicoes.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["operacao", "tamanho_da_base", "execucao", "tempo_ms"])
        w.writerows(linhas)

    (cod10, nome10) = resultados[10000]
    hist = estatisticas(tempos_hist)
    veredito = lambda maior, limite: "ATENDE" if maior <= limite else "NÃO ATENDE"
    texto = [
        f"ESTUDO QUANTITATIVO — {EXECUCOES} execuções por medida (tempos em milissegundos)",
        "",
        f"{'medida':<46}{'média':>10}{'desvio':>10}{'maior':>10}{'limite':>9}  veredito",
        f"{'RNF-02 busca por código, 10 mil participantes':<46}{cod10[0]:>10.4f}{cod10[1]:>10.4f}{cod10[2]:>10.4f}{50:>9}  {veredito(cod10[2], 50)}",
        f"{'RNF-02 busca por nome, 10 mil participantes':<46}{nome10[0]:>10.2f}{nome10[1]:>10.2f}{nome10[2]:>10.2f}{500:>9}  {veredito(nome10[2], 500)}",
        f"{f'RNF-04 histórico, {total_reg} registros':<46}{hist[0]:>10.3f}{hist[1]:>10.3f}{hist[2]:>10.3f}{200:>9}  {veredito(hist[2], 200)}",
        "",
        "Crescimento com o tamanho da base (média):",
        f"{'participantes':>14}{'código (ms)':>14}{'nome (ms)':>12}{'nome ÷ código':>16}",
    ]
    for n, mc, mn in zip(TAMANHOS, medias["codigo"], medias["nome"]):
        texto.append(f"{n:>14}{mc:>14.4f}{mn:>12.2f}{mn / mc:>16.0f}×")
    texto += ["", "Leitura: a busca por código fica praticamente constante (tabela hash, O(1)); a busca por nome",
              "cresce em proporção ao número de participantes (varredura linear, O(n))."]
    (SAIDA / "resumo.txt").write_text("\n".join(texto) + "\n", encoding="utf-8")
    print("\n" + "\n".join(texto))
    grafico(medias)


def grafico(medias):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("\n(matplotlib não instalado — gráfico não gerado; instale com: pip install matplotlib)")
        return
    SUPERFICIE, TEXTO, TEXTO2, GRADE = "#fcfcfb", "#0b0b0b", "#52514e", "#e6e5e0"
    AZUL, LARANJA = "#2a78d6", "#eb6834"
    fig, ax = plt.subplots(figsize=(8, 4.6), dpi=200)
    fig.patch.set_facecolor(SUPERFICIE)
    ax.set_facecolor(SUPERFICIE)
    x = TAMANHOS
    for serie, cor, rotulo in (("nome", LARANJA, "Busca por nome (varredura, O(n))"),
                               ("codigo", AZUL, "Busca por código (tabela hash, O(1))")):
        ax.plot(x, medias[serie], color=cor, linewidth=2, solid_capstyle="round", solid_joinstyle="round",
                marker="o", markersize=6, markeredgecolor=SUPERFICIE, markeredgewidth=2, label=rotulo)
        y_fim = medias[serie][-1]
        valor = f"{y_fim:.2f}" if y_fim >= 0.1 else f"{y_fim:.4f}"
        ax.annotate(valor.replace(".", ",") + " ms", (x[-1], y_fim),
                    xytext=(8, 0), textcoords="offset points", va="center", fontsize=9, color=TEXTO)
    ax.set_title("Tempo médio de busca × tamanho da base (30 execuções por ponto)",
                 loc="left", fontsize=11, color=TEXTO, pad=12)
    ax.set_xlabel("Participantes cadastrados", fontsize=9, color=TEXTO2)
    ax.set_ylabel("Tempo médio (ms)", fontsize=9, color=TEXTO2)
    ax.set_xticks(x)
    ax.set_xticklabels([f"{v:,}".replace(",", ".") for v in x])
    ax.set_ylim(bottom=0)
    ax.set_xlim(0, x[-1] * 1.15)
    ax.grid(axis="y", color=GRADE, linewidth=1)
    for lado in ("top", "right", "left"):
        ax.spines[lado].set_visible(False)
    ax.spines["bottom"].set_color(GRADE)
    ax.tick_params(colors=TEXTO2, labelsize=8, length=0)
    ax.legend(frameon=False, fontsize=9, loc="upper left", labelcolor=TEXTO)
    fig.tight_layout()
    fig.savefig(SAIDA / "grafico_buscas.png", facecolor=SUPERFICIE)
    print(f"\nGráfico salvo em {SAIDA / 'grafico_buscas.png'}")


if __name__ == "__main__":
    medir()
