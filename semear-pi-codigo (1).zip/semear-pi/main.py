"""Instituto Semear — componente em linha de comando.

  python main.py preparar   gera a base sintética, cria o banco e faz a carga inicial (RF-12)
  python main.py            abre o menu (pede o código do profissional)
  python main.py resumo 2026 3     imprime o resumo do 3º trimestre de 2026 (RF-09)
  python main.py consultas         imprime as 10 consultas gerenciais (RF-08)
"""
import datetime as dt
import sys

from semear.banco import BANCO_PADRAO, ErroRegra, conectar, criar_banco
from semear.servicos import CONDICOES, Componente

FUNCOES = {"coordenacao": "Coordenação", "educador": "Educador social",
           "auxiliar": "Auxiliar administrativo", "assistente_social": "Assistente social"}


# ---------------------------------------------------------------- impressão
def tabela(colunas, linhas, limite=40):
    linhas = [["" if v is None else str(v) for v in l] for l in linhas]
    larg = [max([len(c)] + [len(l[i]) for l in linhas[:limite]]) for i, c in enumerate(colunas)]
    larg = [min(w, 40) for w in larg]
    print("  " + "  ".join(c.ljust(larg[i]) for i, c in enumerate(colunas)))
    print("  " + "  ".join("-" * w for w in larg))
    for l in linhas[:limite]:
        print("  " + "  ".join(v[:40].ljust(larg[i]) for i, v in enumerate(l)))
    if len(linhas) > limite:
        print(f"  ... ({len(linhas) - limite} linhas a mais)")
    if not linhas:
        print("  (nenhum resultado)")


def perguntar(texto, padrao=None):
    resp = input(f"{texto}{f' [{padrao}]' if padrao else ''}: ").strip()
    return resp or (padrao or "")


def ok(msg):
    print(f"  ✔ {msg}")


def erro(msg):
    print(f"  ✘ {msg}")


# ---------------------------------------------------------------- telas
def tela_lancar(c):
    """RF-01 / RF-02: percorre os inscritos e pergunta P, F ou FJ para cada um."""
    cod_of = perguntar("Código da oficina (ex.: OF01)").upper()
    data = perguntar("Data do encontro (AAAA-MM-DD)", dt.date.today().isoformat())
    enc = [e for e in c.encontros(cod_of) if e["data"] == data and e["situacao"] != "cancelada"]
    if not enc:
        if perguntar("Não há encontro nesta data. Criar agora? (s/n)", "s").lower() != "s":
            return
        id_ed = c.programar_encontro(cod_of, data)
    else:
        id_ed = enc[0]["id_edicao"]
    inscritos = c.con.execute(
        """SELECT i.cod_participante, p.nome FROM inscricao i JOIN participante p USING (cod_participante)
            WHERE i.cod_oficina = ? AND i.situacao = 'ativa'
              AND i.id_inscricao NOT IN (SELECT id_inscricao FROM registro_frequencia WHERE id_edicao = ?)
            ORDER BY p.nome""", (cod_of, id_ed)).fetchall()
    if not inscritos:
        print("  Todos os inscritos já têm registro neste encontro.")
        return
    print("\n  Para cada pessoa digite P (presente), F (falta) ou FJ (falta justificada).")
    print("  Enter = P   |   D = desfazer o anterior   |   S = sair\n")
    i = 0
    while i < len(inscritos):
        cod, nome = inscritos[i]
        resp = perguntar(f"  {cod}  {nome}", "P").upper()
        if resp == "S":
            break
        if resp == "D":
            desfeito = c.desfazer()
            if desfeito:
                ok(f"desfeito o lançamento de {desfeito['cod_participante']}")
                if i > 0 and inscritos[i - 1][0] == desfeito["cod_participante"]:
                    i -= 1
            else:
                erro("não há lançamento para desfazer")
            continue
        try:
            c.lancar_frequencia(id_ed, cod, resp)
            i += 1
        except ErroRegra as e:
            erro(e)
    resumo = c.con.execute("SELECT condicao, COUNT(*) FROM registro_frequencia WHERE id_edicao = ? GROUP BY condicao",
                           (id_ed,)).fetchall()
    print("\n  Resumo do encontro: " + ", ".join(f"{CONDICOES[k]}: {n}" for k, n in resumo))


def tela_desfazer(c):
    d = c.desfazer()
    ok(f"lançamento de {d['cod_participante']} desfeito") if d else erro("não há lançamentos nesta sessão")


def tela_codigo(c):
    p, ms = c.buscar_por_codigo(perguntar("Código do participante"))
    if p:
        tabela(["código", "nome", "família", "nascimento", "prioridade"],
               [[p["cod_participante"], p["nome"], p["cod_familia"], p["data_nascimento"], p["prioridade_legal"]]])
    else:
        erro("participante não encontrado")
    print(f"  tempo da busca: {ms:.3f} ms")


def tela_nome(c):
    lista, ms = c.buscar_por_nome(perguntar("Parte do nome"))
    tabela(["código", "nome", "família"], [[p["cod_participante"], p["nome"], p["cod_familia"]] for p in lista])
    print(f"  {len(lista)} encontrado(s) — tempo da busca: {ms:.3f} ms")


def tela_historico(c):
    h = c.historico(perguntar("Código do participante").upper())
    tabela(["data", "oficina", "tema", "condição", "lançado por", "registro"],
           [[r["data"], r["cod_oficina"], r["tema"], r["condicao"], r["lancado_por"], r["id_registro"]] for r in h])


def tela_cadastro(c):
    nome = perguntar("Nome completo")
    parecidos = c.participantes_parecidos(nome)
    if parecidos:
        print("  Já existem nomes parecidos — confira para não duplicar:")
        tabela(["código", "nome", "família"], [[p["cod_participante"], p["nome"], p["cod_familia"]] for p in parecidos], 10)
        if perguntar("Continuar o cadastro? (s/n)", "n").lower() != "s":
            return
    fam = perguntar("Código da família (Enter = nova família)").upper()
    if not fam:
        fam = c.cadastrar_familia(dt.date.today().isoformat())
        ok(f"família {fam} criada")
    nasc = perguntar("Data de nascimento (AAAA-MM-DD)")
    prio = perguntar("Prioridade legal (nenhuma, idoso, gestante, pcd)", "nenhuma").lower()
    cons = perguntar("Consentimento do responsável registrado? (s/n)", "n").lower() == "s"
    cod = c.cadastrar_participante(fam, nome, nasc, prio, cons)
    ok(f"participante cadastrado com o código {cod}")


def tela_inscrever(c):
    situacao, pos = c.inscrever(perguntar("Código do participante").upper(), perguntar("Código da oficina").upper())
    ok("inscrição ativa") if situacao == "ativa" else ok(f"oficina sem vaga — lista de espera, posição {pos}")


def tela_fila(c):
    op = perguntar("1 = incluir pessoa na fila   2 = chamar próximo", "2")
    if op == "1":
        n = c.incluir_na_fila(perguntar("Código do participante").upper())
        ok(f"incluído; {n} pessoa(s) aguardando")
    else:
        p = c.chamar_proximo()
        ok(f"chamar: {p['cod_participante']} — {p['nome']} ({p['prioridade_legal']})") if p else erro("fila vazia")


def tela_corrigir(c):
    c.corrigir(int(perguntar("Número do registro (veja no histórico)")),
               perguntar("Nova condição (P, F ou FJ)"), perguntar("Motivo da correção"))
    ok("correção registrada com o valor anterior")


def tela_auditoria(c):
    cod = perguntar("Código do participante").upper()
    a = c.auditoria(cod_participante=cod)
    tabela(["registro", "data", "oficina", "condição", "lançado por", "anterior", "corrigido por", "motivo"],
           [[r["id_registro"], r["data"], r["cod_oficina"], r["condicao"], r["lancado_por"],
             r["condicao_anterior"], r["corrigido_por"], r["motivo"]] for r in a])


def imprimir_resumo(c, ano, tri):
    r = c.resumo_trimestral(ano, tri)
    print(f"\n  RESUMO TRIMESTRAL DE ATENDIMENTOS — {tri}º trimestre de {ano} ({r['periodo'][0]} a {r['periodo'][1]})")
    print(f"  {r['regra']}")
    print(f"  Envio ao município e aos doadores até {r['data_limite_envio']} (RN-07)\n")
    tabela(["oficina", "tema", "encontros", "atendimentos", "participantes", "faltas", "faltas just."],
           [[o["cod_oficina"], o["tema"], o["encontros_realizados"], o["atendimentos"], o["participantes_atendidos"],
             o["faltas"], o["faltas_justificadas"]] for o in r["por_oficina"]])
    print(f"\n  Total de atendimentos: {r['total_atendimentos']}   Participantes atendidos: {r['total_participantes']}"
          f"   Famílias atendidas (RN-06): {r['familias_atendidas']}")


def tela_resumo(c):
    imprimir_resumo(c, int(perguntar("Ano", str(dt.date.today().year))), int(perguntar("Trimestre (1 a 4)")))


def imprimir_consultas(c):
    for n, (titulo, colunas, linhas) in enumerate(c.consultas_gerenciais(), start=1):
        print(f"\n  Q{n}. {titulo}")
        tabela(colunas, linhas, limite=12)


MENU = [
    ("Lançar frequência de um encontro", tela_lancar),
    ("Desfazer o último lançamento", tela_desfazer),
    ("Buscar participante por código", tela_codigo),
    ("Buscar participantes por nome", tela_nome),
    ("Histórico de um participante", tela_historico),
    ("Cadastrar participante", tela_cadastro),
    ("Inscrever participante em oficina", tela_inscrever),
    ("Fila da assistente social", tela_fila),
    ("Corrigir um registro (coordenação)", tela_corrigir),
    ("Auditoria de um participante", tela_auditoria),
    ("Resumo trimestral", tela_resumo),
    ("Consultas gerenciais", imprimir_consultas),
]


def menu():
    if not BANCO_PADRAO.exists():
        erro("Banco não encontrado. Rode antes:  python main.py preparar")
        return
    con = conectar()
    while True:
        try:
            c = Componente(con, perguntar("Seu código de profissional (ex.: C01, E01, A01, S01)").upper())
            break
        except ErroRegra as e:
            erro(e)
    print(f"\n  Olá! Perfil: {FUNCOES[c.profissional['funcao']]}")
    while True:
        print("\n  ===== INSTITUTO SEMEAR =====")
        for i, (texto, _) in enumerate(MENU, start=1):
            print(f"  {i:>2}. {texto}")
        print("   0. Sair")
        op = perguntar("Opção")
        if op == "0":
            break
        if not op.isdigit() or not 1 <= int(op) <= len(MENU):
            erro("opção inválida")
            continue
        try:
            MENU[int(op) - 1][1](c)
        except ErroRegra as e:
            erro(e)
        except (ValueError, KeyError) as e:
            erro(f"entrada inválida ({e})")


def preparar():
    import gerar_dados
    from semear.carga import carregar
    gerar_dados.gerar()
    print("Base bruta sintética gerada em dados/bruto/")
    con = criar_banco(apagar=True)
    print(f"Banco criado em {BANCO_PADRAO.name}\n\nCARGA INICIAL (RF-12)")
    rel = carregar(con)
    print(rel.resumo())
    print("\nRegistros rejeitados, com o motivo, em dados/rejeicoes.csv")


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(errors="replace")   # console do Windows sem UTF-8 não quebra com ✔/✘
    except AttributeError:
        pass
    args = sys.argv[1:]
    if not args:
        menu()
    elif args[0] == "preparar":
        preparar()
    elif args[0] == "resumo" and len(args) == 3:
        imprimir_resumo(Componente(conectar(), "C01"), int(args[1]), int(args[2]))
    elif args[0] == "consultas":
        imprimir_consultas(Componente(conectar(), "C01"))
    else:
        print(__doc__)
